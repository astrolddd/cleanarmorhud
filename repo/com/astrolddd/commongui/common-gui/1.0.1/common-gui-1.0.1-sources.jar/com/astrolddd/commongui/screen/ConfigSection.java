package com.astrolddd.commongui.screen;

import com.astrolddd.commongui.theme.UiTheme;
import com.astrolddd.commongui.widget.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Represents a card section within a {@link ConfigTab}.
 * Manages rows, inputs, toggles, sliders, dropdowns, and custom widgets.
 */
public class ConfigSection {
    private final String title;
    private final String subtitle;
    private final List<ConfigEntry> entries = new ArrayList<>();

    public ConfigSection(String title) {
        this(title, null);
    }

    public ConfigSection(String title, String subtitle) {
        this.title = title;
        this.subtitle = subtitle;
    }

    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public List<ConfigEntry> getEntries() {
        return entries;
    }

    public ConfigSection addToggle(String label, boolean current, Consumer<Boolean> onToggle) {
        entries.add(new ConfigEntry() {
            @Override
            public int getHeight() {
                return 28;
            }

            @Override
            public List<Widget> createWidgets(int x, int y, int width) {
                int labelW = width - 60;
                Widget labelWidget = new Widget(x, y, labelW, 20) {
                    @Override
                    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
                        Font font = Minecraft.getInstance().font;
                        g.text(font, UiTheme.text(label), this.x, this.y + 6, UiTheme.TEXT_PRIMARY, false);
                    }
                };
                ToggleSwitch sw = new ToggleSwitch(x + width - 46, y + 4, 46, 20, current, onToggle);
                return List.of(labelWidget, sw);
            }
        });
        return this;
    }

    public ConfigSection addSlider(String label, double min, double max, double value, double defVal,
                                   Function<Double, String> labelProvider, Consumer<Double> onChange) {
        entries.add(new ConfigEntry() {
            @Override
            public int getHeight() {
                return 28;
            }

            @Override
            public List<Widget> createWidgets(int x, int y, int width) {
                int sliderW = 120;
                int labelW = width - sliderW - 60;
                Widget labelWidget = new Widget(x, y, labelW, 20) {
                    @Override
                    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
                        Font font = Minecraft.getInstance().font;
                        g.text(font, UiTheme.text(label), this.x, this.y + 5, UiTheme.TEXT_PRIMARY, false);
                    }
                };
                SmoothSlider slider = new SmoothSlider(x + width - sliderW - 52, y + 4, sliderW, 20, min, max, value, defVal, labelProvider, onChange);
                return List.of(labelWidget, slider);
            }
        });
        return this;
    }

    public ConfigSection addSlider(String label, double min, double max, double value, double defVal,
                                   String suffix, Consumer<Double> onChange) {
        return addSlider(label, min, max, value, defVal,
                val -> String.format(Locale.ROOT, "%.0f %s", val, suffix != null ? suffix : ""), onChange);
    }

    public <T> ConfigSection addDropdown(String label, List<DropdownWidget.DropdownItem<T>> items, T selected, Consumer<T> onSelect) {
        entries.add(new ConfigEntry() {
            @Override
            public int getHeight() {
                return 28;
            }

            @Override
            public List<Widget> createWidgets(int x, int y, int width) {
                int ddW = Math.min(140, width / 2);
                int labelW = width - ddW - 12;
                Widget labelWidget = new Widget(x, y, labelW, 22) {
                    @Override
                    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
                        Font font = Minecraft.getInstance().font;
                        g.text(font, UiTheme.text(label), this.x, this.y + 6, UiTheme.TEXT_PRIMARY, false);
                    }
                };
                DropdownWidget<T> dd = new DropdownWidget<>(x + width - ddW, y + 3, ddW, 22, items, selected, onSelect);
                return List.of(labelWidget, dd);
            }
        });
        return this;
    }

    public ConfigSection addButton(String label, String buttonText, Consumer<RoundedButton> onPress) {
        entries.add(new ConfigEntry() {
            @Override
            public int getHeight() {
                return 28;
            }

            @Override
            public List<Widget> createWidgets(int x, int y, int width) {
                int btnW = 120;
                int labelW = width - btnW - 10;
                Widget labelWidget = new Widget(x, y, labelW, 22) {
                    @Override
                    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
                        Font font = Minecraft.getInstance().font;
                        g.text(font, UiTheme.text(label), this.x, this.y + 6, UiTheme.TEXT_PRIMARY, false);
                    }
                };
                RoundedButton btn = new RoundedButton(x + width - btnW, y + 3, btnW, 22, Component.literal(buttonText), onPress);
                return List.of(labelWidget, btn);
            }
        });
        return this;
    }

    public ConfigSection addButton(String buttonText, Consumer<RoundedButton> onPress) {
        entries.add(new ConfigEntry() {
            @Override
            public int getHeight() {
                return 28;
            }

            @Override
            public List<Widget> createWidgets(int x, int y, int width) {
                int btnW = Math.min(130, width);
                RoundedButton btn = new RoundedButton(x, y + 3, btnW, 22, Component.literal(buttonText), onPress);
                return List.of(btn);
            }
        });
        return this;
    }

    public ConfigSection addWidget(Widget widget) {
        return addWidget(widget, widget.height + 6);
    }

    public ConfigSection addWidget(Widget widget, int height) {
        entries.add(new ConfigEntry() {
            @Override
            public int getHeight() {
                return height;
            }

            @Override
            public List<Widget> createWidgets(int x, int y, int width) {
                widget.x = x;
                widget.y = y;
                return List.of(widget);
            }
        });
        return this;
    }

    public ConfigSection addCustomRow(Widget labelWidget, Widget controlWidget) {
        return addCustomRow(labelWidget, controlWidget, 28);
    }

    public ConfigSection addCustomRow(Widget labelWidget, Widget controlWidget, int height) {
        entries.add(new ConfigEntry() {
            @Override
            public int getHeight() {
                return height;
            }

            @Override
            public List<Widget> createWidgets(int x, int y, int width) {
                labelWidget.x = x;
                labelWidget.y = y;
                controlWidget.x = x + width - controlWidget.width;
                controlWidget.y = y;
                return List.of(labelWidget, controlWidget);
            }
        });
        return this;
    }
}
