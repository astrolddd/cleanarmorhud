package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Standardized configuration row generator for CommonGUI.
 * Ensures all row labels automatically use the configured TrueType font (Segoe UI)
 * and correct layout alignments across all mods.
 */
public final class SettingRow {
    private SettingRow() {}

    public static Widget createLabel(int x, int y, int width, int height, String label) {
        return new Widget(x, y, width, height) {
            @Override
            public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
                Font font = Minecraft.getInstance().font;
                g.text(font, UiTheme.text(label), this.x, this.y + (this.height - 8) / 2, UiTheme.TEXT_PRIMARY, false);
            }
        };
    }

    public static List<Widget> toggle(int rx, int ry, int rowW, String label, boolean current, Consumer<Boolean> onToggle) {
        Widget labelWidget = createLabel(rx, ry, rowW - 60, 20, label);
        ToggleSwitch sw = new ToggleSwitch(rx + rowW - 46, ry, 46, 20, current, onToggle);
        return List.of(labelWidget, sw);
    }

    public static <T> List<Widget> dropdown(int rx, int ry, int rowW, String label, int dropdownW, List<DropdownWidget.DropdownItem<T>> items, T selected, Consumer<T> onSelect) {
        Widget labelWidget = createLabel(rx, ry, rowW - dropdownW - 12, 22, label);
        DropdownWidget<T> dd = new DropdownWidget<>(rx + rowW - dropdownW, ry, dropdownW, 22, items, selected, onSelect);
        return List.of(labelWidget, dd);
    }

    public static List<Widget> slider(int rx, int ry, int rowW, String label, double min, double max, double value, double defVal, Function<Double, String> labelProvider, Consumer<Double> onChange) {
        int sliderW = 120;
        int labelW = rowW - sliderW - 60;
        Widget labelWidget = createLabel(rx, ry, labelW, 20, label);
        SmoothSlider slider = new SmoothSlider(rx + rowW - sliderW - 52, ry, sliderW, 20, min, max, value, defVal, labelProvider, onChange);
        return List.of(labelWidget, slider);
    }
}
