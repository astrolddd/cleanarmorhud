package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.anim.Anim;
import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;

import java.util.function.Consumer;

public class SidebarTab extends Widget {
    private final String label;
    private boolean selected;
    private final Consumer<SidebarTab> onSelect;

    private final com.astrolddd.commongui.anim.Spring selectSpring;
    private final com.astrolddd.commongui.anim.Spring hoverSpring;
    private long lastFrameNanos = 0;

    public SidebarTab(int x, int y, int width, int height, String label, boolean selected, Consumer<SidebarTab> onSelect) {
        super(x, y, width, height);
        this.label = label;
        this.selected = selected;
        this.onSelect = onSelect;
        this.selectSpring = new com.astrolddd.commongui.anim.Spring(selected ? 1.0f : 0.0f, 260.0f, 22.0f);
        this.hoverSpring = new com.astrolddd.commongui.anim.Spring(0.0f, 240.0f, 22.0f);
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public String getLabel() {
        return label;
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible) return;
        updateHover(mouseX, mouseY);

        long now = System.nanoTime();
        float dt = lastFrameNanos == 0 ? 0.016f : (float) ((now - lastFrameNanos) / 1_000_000_000.0);
        lastFrameNanos = now;

        selectSpring.step(selected ? 1.0f : 0.0f, dt);
        hoverSpring.step((hovered && !selected) ? 1.0f : 0.0f, dt);

        float sel = selectSpring.getValue();
        float hov = hoverSpring.getValue();

        if (sel > 0.01f) {
            int selColor = Anim.lerpColor(0x00FFFFFF & UiTheme.TAB_SELECTED, UiTheme.TAB_SELECTED, sel);
            Draw.pill(g, x, y, width, height, selColor);
            Draw.pillOutline(g, x, y, width, height, 1, Anim.lerpColor(0, 0x1EFFFFFF, sel));
        } else if (hov > 0.01f) {
            int hovColor = Anim.lerpColor(0x00FFFFFF & UiTheme.BTN_HOVER, UiTheme.BTN_HOVER, hov);
            Draw.pill(g, x, y, width, height, hovColor);
        }

        Font font = Minecraft.getInstance().font;
        int textY = y + (height - 8) / 2;
        float textBright = Math.max(sel, hov * 0.75f);
        int textColor = Anim.lerpColor(UiTheme.TEXT_SECONDARY, UiTheme.TEXT_PRIMARY, textBright);
        int textX = x + 12 + (int) Math.round(sel * 2.0f);

        g.text(font, UiTheme.text(label), textX, textY, textColor, false);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!enabled || !visible) return false;
        if (isLeftClick(event) && isMouseOver(event.x(), event.y())) {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.0F));
            if (onSelect != null) {
                onSelect.accept(this);
            }
            return true;
        }
        return false;
    }
}
