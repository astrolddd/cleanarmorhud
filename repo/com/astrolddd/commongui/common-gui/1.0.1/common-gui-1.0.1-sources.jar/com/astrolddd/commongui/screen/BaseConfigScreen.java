package com.astrolddd.commongui.screen;

import com.astrolddd.commongui.anim.Anim;
import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import com.astrolddd.commongui.update.UpdateChecker;
import com.astrolddd.commongui.widget.*;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.Window;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Modern, extensible base class for configuration screens across CommonGUI-powered mods.
 * Handles window animations, layout geometry, sidebar navigation, scrolling,
 * header/footer controls, theme syncing, and overlay dialogs out of the box.
 */
public abstract class BaseConfigScreen extends Screen {
    protected final Screen parent;
    protected final Component screenTitle;
    protected final String modId;
    protected final String modTitle;

    protected boolean showSidebar = true;
    protected int activeTab = 0;
    protected final List<ConfigTab> tabs = new ArrayList<>();
    protected final List<SidebarTab> sidebarTabs = new ArrayList<>();
    protected final List<Widget> currentTabWidgets = new ArrayList<>();

    // Modal Geometry
    protected int modalX, modalY, modalW, modalH;
    protected int sidebarW;
    protected int contentX, contentY, contentW, contentH;

    // Core Chrome & Widgets
    protected ScrollContainer scrollContainer;
    protected CloseButton closeButton;
    protected ThemeToggleButton themeToggleButton;
    protected BookIconButton bookButton;
    protected DownloadIconButton downloadButton;
    protected RoundedButton resetDefaultsButton;
    protected RoundedButton cancelButton;
    protected RoundedButton doneButton;

    // Overlays
    protected ChangelogDialog changelogDialog;
    protected ConfirmDialog confirmResetDialog;
    protected UpdateChecker updateChecker;

    // Animations
    protected float openProgress = 0.0f;
    protected boolean isClosing = false;
    protected float exitProgress = 0.0f;

    public BaseConfigScreen(Component screenTitle, Screen parent) {
        this(screenTitle, parent, null, null);
    }

    public BaseConfigScreen(Component screenTitle, Screen parent, String modId, String modTitle) {
        super(screenTitle);
        this.screenTitle = screenTitle;
        this.parent = parent;
        this.modId = modId;
        this.modTitle = modTitle;
    }

    /**
     * Declares tabs and setting entries using {@link #addTab(String)}.
     */
    protected abstract void buildConfig();

    /**
     * Called when the player clicks "Done" to persist modified settings.
     */
    protected abstract void onSave();

    /**
     * Called when the player confirms "Reset Defaults".
     */
    protected abstract void onResetDefaults();

    /**
     * Optional lifecycle hook called whenever a setting is altered.
     */
    protected void onSettingChanged() {}

    /**
     * Optional lifecycle hook called when the light/dark theme is toggled.
     */
    protected void onThemeToggled(boolean isDark) {}

    /**
     * Optional lifecycle hook called when the player clicks "Cancel" or closes without saving.
     */
    protected void onCancel() {}

    /**
     * Creates and registers a new category tab on the sidebar.
     */
    protected ConfigTab addTab(String name) {
        ConfigTab tab = new ConfigTab(name);
        tabs.add(tab);
        return tab;
    }

    public void setShowSidebar(boolean showSidebar) {
        this.showSidebar = showSidebar;
    }

    @Override
    protected void init() {
        UiTheme.setFont("segoeui");
        openProgress = 0.0f;
        isClosing = false;
        exitProgress = 0.0f;

        applyOptimalScale();

        // Calculate responsive window bounds (~82% clamped)
        int targetW = Math.max(500, Math.min(840, (int) (width * 0.82)));
        modalW = Math.min(width - 16, targetW);
        int targetH = Math.max(380, Math.min(520, (int) (height * 0.82)));
        modalH = Math.min(height - 16, targetH);
        modalX = Math.max(8, (width - modalW) / 2);
        modalY = Math.max(8, (height - modalH) / 2);

        // Build categories
        tabs.clear();
        buildConfig();

        boolean hasSidebar = showSidebar && tabs.size() > 1;
        sidebarW = hasSidebar ? 140 : 0;
        contentX = modalX + sidebarW + (hasSidebar ? 14 : 16);
        contentY = modalY + 44;
        contentW = modalW - sidebarW - (hasSidebar ? 28 : 32);
        contentH = modalH - 44 - 44;

        scrollContainer = new ScrollContainer(contentX, contentY, contentW, contentH);

        // Update checker & Changelog dialog
        if (modTitle != null && !modTitle.isBlank()) {
            if (updateChecker == null && modId != null) {
                updateChecker = UpdateChecker.get(modId);
                if (updateChecker == null) {
                    updateChecker = UpdateChecker.register(modId, modId, false);
                }
            }
            if (changelogDialog == null) {
                changelogDialog = new ChangelogDialog(modTitle, updateChecker);
            }
        }

        // Header controls
        int headerBtnY = modalY + 8;
        int btnRight = modalX + modalW - 28;

        closeButton = new CloseButton(btnRight, headerBtnY, 20, b -> onClose());
        btnRight -= 24;

        themeToggleButton = new ThemeToggleButton(btnRight, headerBtnY, 20, b -> {
            boolean newDark = !UiTheme.isDark();
            UiTheme.setDarkMode(newDark);
            onThemeToggled(newDark);
        });
        btnRight -= 24;

        if (modTitle != null && !modTitle.isBlank() && changelogDialog != null) {
            bookButton = new BookIconButton(btnRight, headerBtnY, 20, b -> changelogDialog.show());
            btnRight -= 24;

            if (updateChecker != null) {
                downloadButton = new DownloadIconButton(btnRight, headerBtnY, 20, updateChecker, b -> {
                    String url = updateChecker.getDownloadUrl();
                    if (url != null) UpdateChecker.openUrl(url);
                });
            }
        }

        // Footer controls
        int footerY = modalY + modalH - 34;
        resetDefaultsButton = new RoundedButton(modalX + 16, footerY, 110, 24,
                Component.literal("Reset Defaults"), b -> confirmReset());
        cancelButton = new RoundedButton(modalX + modalW - 186, footerY, 80, 24,
                Component.literal("Cancel"), b -> {
                    onCancel();
                    onClose();
                });
        doneButton = new RoundedButton(modalX + modalW - 96, footerY, 80, 24,
                Component.literal("Done"), b -> saveAndClose());

        // Reset confirmation modal
        confirmResetDialog = new ConfirmDialog(
                "Reset to Defaults?",
                "Are you sure you want to restore all settings to default values? This action cannot be undone.",
                "Reset",
                "Cancel",
                () -> {
                    onResetDefaults();
                    rebuildTabs();
                },
                null
        );

        // Sidebar tabs
        updateSidebarTabs();
        assembleActiveTabWidgets();
    }

    protected void updateSidebarTabs() {
        sidebarTabs.clear();
        boolean hasSidebar = showSidebar && tabs.size() > 1;
        if (!hasSidebar) return;

        int tabY = modalY + 44;
        for (int i = 0; i < tabs.size(); i++) {
            final int tabIndex = i;
            sidebarTabs.add(new SidebarTab(modalX + 8, tabY + i * 28, sidebarW - 16, 26,
                    tabs.get(i).getName(), activeTab == i, t -> switchTab(tabIndex)));
        }
    }

    public void switchTab(int index) {
        if (index >= 0 && index < tabs.size()) {
            this.activeTab = index;
            for (int i = 0; i < sidebarTabs.size(); i++) {
                sidebarTabs.get(i).setSelected(i == index);
            }
            assembleActiveTabWidgets();
            scrollContainer.setScrollY(0);
        }
    }

    public void rebuildTabs() {
        int prevTab = activeTab;
        tabs.clear();
        buildConfig();
        if (prevTab < tabs.size()) {
            activeTab = prevTab;
        } else {
            activeTab = Math.max(0, tabs.size() - 1);
        }
        updateSidebarTabs();
        assembleActiveTabWidgets();
    }

    protected void assembleActiveTabWidgets() {
        currentTabWidgets.clear();
        if (tabs.isEmpty()) return;

        if (activeTab >= tabs.size()) {
            activeTab = 0;
        }

        ConfigTab tab = tabs.get(activeTab);
        int cardInnerW = contentW - 28;
        int curY = contentY + 4;

        for (ConfigSection section : tab.getSections()) {
            int headerH = (section.getSubtitle() != null && !section.getSubtitle().isBlank()) ? 38 : 26;
            int sectionContentH = 0;
            for (ConfigEntry entry : section.getEntries()) {
                sectionContentH += entry.getHeight();
            }
            int secH = headerH + sectionContentH + 8;

            SectionCard card = new SectionCard(contentX, curY, contentW, secH, section.getTitle(), section.getSubtitle());
            currentTabWidgets.add(card);

            int rY = curY + headerH;
            for (ConfigEntry entry : section.getEntries()) {
                List<Widget> rowWidgets = entry.createWidgets(contentX + 14, rY, cardInnerW);
                currentTabWidgets.addAll(rowWidgets);
                rY += entry.getHeight();
            }

            curY += secH + 12;
        }

        for (Widget standalone : tab.getStandaloneWidgets()) {
            currentTabWidgets.add(standalone);
            curY += standalone.height + 12;
        }

        scrollContainer.setContentHeight(curY - contentY + 24);
    }

    private void confirmReset() {
        if (confirmResetDialog != null) {
            confirmResetDialog.show();
        }
    }

    private void saveAndClose() {
        onSave();
        onClose();
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        float bgFactor = isClosing ? Math.max(0.0f, 1.0f - exitProgress) : openProgress;
        if (minecraft != null && minecraft.level != null) {
            try {
                extractBlurredBackground(graphics);
            } catch (Exception ignored) {
            }
            int a = Math.round(((UiTheme.BACKDROP_OVERLAY >>> 24) & 0xFF) * bgFactor);
            graphics.fill(0, 0, width, height, (a << 24) | (UiTheme.BACKDROP_OVERLAY & 0x00FFFFFF));
        } else {
            graphics.fill(0, 0, width, height, UiTheme.BACKDROP_SOLID);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        extractBackground(g, mouseX, mouseY, delta);

        if (openProgress < 1.0f) {
            openProgress = Anim.approach(openProgress, 1.0f, 100.0f, delta * 50.0f);
        }

        if (isClosing) {
            exitProgress = Anim.approach(exitProgress, 1.0f, 100.0f, delta * 50.0f);
            if (exitProgress >= 0.99f) {
                reallyClose();
                return;
            }
        }

        boolean hasSidebar = showSidebar && tabs.size() > 1;

        // 1. Soft shadow & Window surface
        Draw.softShadow(g, modalX, modalY, modalW, modalH, UiTheme.RADIUS_WINDOW, 8, 0x80);
        Draw.roundedRect(g, modalX, modalY, modalW, modalH, UiTheme.RADIUS_WINDOW, UiTheme.WINDOW_SURFACE);
        Draw.roundedOutline(g, modalX, modalY, modalW, modalH, UiTheme.RADIUS_WINDOW, 1, UiTheme.CARD_BORDER);

        // 2. Sidebar background & divider
        if (hasSidebar) {
            Draw.roundedRect(g, modalX, modalY, sidebarW, modalH, UiTheme.RADIUS_WINDOW, UiTheme.SIDEBAR_BG);
            g.fill(modalX + sidebarW - UiTheme.RADIUS_WINDOW - 2, modalY, modalX + sidebarW, modalY + modalH, UiTheme.SIDEBAR_BG);
            g.fill(modalX + sidebarW, modalY, modalX + sidebarW + 1, modalY + modalH, UiTheme.DIVIDER);

            for (SidebarTab tab : sidebarTabs) {
                tab.extractWidgetRenderState(g, mouseX, mouseY, delta);
            }
        }

        // 3. Header title
        Font font = Minecraft.getInstance().font;
        g.text(font, UiTheme.text(screenTitle), modalX + 16, modalY + 14, UiTheme.TEXT_PRIMARY, false);

        // 4. Header buttons
        if (downloadButton != null) downloadButton.extractWidgetRenderState(g, mouseX, mouseY, delta);
        if (bookButton != null) bookButton.extractWidgetRenderState(g, mouseX, mouseY, delta);
        if (themeToggleButton != null) themeToggleButton.extractWidgetRenderState(g, mouseX, mouseY, delta);
        if (closeButton != null) closeButton.extractWidgetRenderState(g, mouseX, mouseY, delta);

        // 5. Scroll container & child widgets
        scrollContainer.beginRender(g, mouseX, mouseY, delta);
        int scrollYOffset = Math.round(scrollContainer.getScrollY());
        for (Widget widget : currentTabWidgets) {
            int origY = widget.y;
            widget.y -= scrollYOffset;
            widget.extractWidgetRenderState(g, mouseX, mouseY, delta);
            widget.y = origY;
        }
        scrollContainer.endRender(g);

        // 6. Footer divider and buttons
        g.fill(modalX, modalY + modalH - 42, modalX + modalW, modalY + modalH - 41, UiTheme.DIVIDER);
        if (resetDefaultsButton != null) resetDefaultsButton.extractWidgetRenderState(g, mouseX, mouseY, delta);
        if (cancelButton != null) cancelButton.extractWidgetRenderState(g, mouseX, mouseY, delta);
        if (doneButton != null) doneButton.extractWidgetRenderState(g, mouseX, mouseY, delta);

        // 7. Dropdown popup overlays (rendered above scissor bounds)
        for (Widget widget : currentTabWidgets) {
            if (widget instanceof DropdownWidget<?> dd && dd.isOpen()) {
                int origY = dd.y;
                dd.y -= scrollYOffset;
                dd.extractPopupRenderState(g, mouseX, mouseY, delta);
                dd.y = origY;
            }
        }

        // 8. Dialog modals
        if (confirmResetDialog != null && confirmResetDialog.isActive()) {
            confirmResetDialog.render(g, width, height, mouseX, mouseY, delta);
        }
        if (changelogDialog != null && changelogDialog.isActive()) {
            changelogDialog.render(g, width, height, mouseX, mouseY, delta);
        }

        // Opening / Closing fade veil
        if (openProgress < 0.99f && !isClosing) {
            int openA = Math.min(255, Math.round((1.0f - openProgress) * 255.0f));
            int baseRgb = minecraft != null && minecraft.level != null ? 0x141416 : (UiTheme.BACKDROP_SOLID & 0x00FFFFFF);
            g.fill(modalX - 4, modalY - 4, modalX + modalW + 4, modalY + modalH + 4, (openA << 24) | baseRgb);
        }
        if (isClosing && exitProgress > 0.01f) {
            int exitA = Math.min(255, Math.round(exitProgress * 255.0f));
            int baseRgb = minecraft != null && minecraft.level != null ? 0x141416 : (UiTheme.BACKDROP_SOLID & 0x00FFFFFF);
            g.fill(modalX - 4, modalY - 4, modalX + modalW + 4, modalY + modalH + 4, (exitA << 24) | baseRgb);
        }

        super.extractRenderState(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (isClosing) return true;

        if (changelogDialog != null && changelogDialog.isActive()) {
            return changelogDialog.mouseClicked(event, doubleClick);
        }
        if (confirmResetDialog != null && confirmResetDialog.isActive()) {
            return confirmResetDialog.mouseClicked(event, doubleClick);
        }

        if (downloadButton != null && downloadButton.mouseClicked(event, doubleClick)) return true;
        if (bookButton != null && bookButton.mouseClicked(event, doubleClick)) return true;
        if (themeToggleButton != null && themeToggleButton.mouseClicked(event, doubleClick)) return true;
        if (closeButton != null && closeButton.mouseClicked(event, doubleClick)) return true;
        if (doneButton != null && doneButton.mouseClicked(event, doubleClick)) return true;
        if (cancelButton != null && cancelButton.mouseClicked(event, doubleClick)) return true;
        if (resetDefaultsButton != null && resetDefaultsButton.mouseClicked(event, doubleClick)) return true;

        for (SidebarTab tab : sidebarTabs) {
            if (tab.mouseClicked(event, doubleClick)) return true;
        }

        int scrollYOffset = Math.round(scrollContainer.getScrollY());

        // Check active dropdown popup first
        for (Widget widget : currentTabWidgets) {
            if (widget instanceof DropdownWidget<?> dd && dd.isOpen()) {
                int origY = dd.y;
                dd.y -= scrollYOffset;
                boolean res = dd.mouseClicked(event, doubleClick);
                dd.y = origY;
                if (res) return true;
            }
        }

        if (scrollContainer.mouseClicked(event, doubleClick)) return true;

        if (event.x() >= contentX && event.x() <= contentX + contentW &&
            event.y() >= contentY && event.y() <= contentY + contentH) {
            var widgetsCopy = new ArrayList<>(currentTabWidgets);
            for (Widget widget : widgetsCopy) {
                int origY = widget.y;
                widget.y -= scrollYOffset;
                boolean res = widget.mouseClicked(event, doubleClick);
                widget.y = origY;
                if (res) return true;
            }
        }

        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        if (isClosing) return true;
        if (scrollContainer.mouseDragged(event, deltaX, deltaY)) return true;

        int scrollYOffset = Math.round(scrollContainer.getScrollY());
        for (Widget widget : currentTabWidgets) {
            int origY = widget.y;
            widget.y -= scrollYOffset;
            boolean res = widget.mouseDragged(event, deltaX, deltaY);
            widget.y = origY;
            if (res) return true;
        }

        return super.mouseDragged(event, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (isClosing) return true;
        if (scrollContainer.mouseReleased(event)) return true;

        int scrollYOffset = Math.round(scrollContainer.getScrollY());
        for (Widget widget : currentTabWidgets) {
            int origY = widget.y;
            widget.y -= scrollYOffset;
            widget.mouseReleased(event);
            widget.y = origY;
        }

        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (isClosing) return true;

        int scrollYOffset = Math.round(scrollContainer.getScrollY());
        for (Widget widget : currentTabWidgets) {
            if (widget instanceof DropdownWidget<?> dd && dd.isOpen()) {
                int origY = dd.y;
                dd.y -= scrollYOffset;
                boolean res = dd.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
                dd.y = origY;
                if (res) return true;
            }
        }

        if (scrollContainer.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount)) {
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (isClosing) return true;
        if (event.key() == InputConstants.KEY_ESCAPE) {
            if (changelogDialog != null && changelogDialog.isActive()) {
                changelogDialog.close();
                return true;
            }
            if (confirmResetDialog != null && confirmResetDialog.isActive()) {
                confirmResetDialog.close();
                return true;
            }
            onClose();
            return true;
        }

        int scrollYOffset = Math.round(scrollContainer.getScrollY());
        for (Widget widget : currentTabWidgets) {
            int origY = widget.y;
            widget.y -= scrollYOffset;
            boolean res = widget.keyPressed(event);
            widget.y = origY;
            if (res) return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (isClosing) return true;
        for (Widget widget : currentTabWidgets) {
            if (widget.charTyped(event)) return true;
        }
        return super.charTyped(event);
    }

    @Override
    public void onClose() {
        if (!isClosing) {
            isClosing = true;
            exitProgress = 0.0f;
        }
    }

    private void reallyClose() {
        restoreGuiScale();
        if (minecraft != null) {
            minecraft.setScreenAndShow(parent);
        }
    }

    @Override
    public void removed() {
        restoreGuiScale();
        super.removed();
    }

    private void applyOptimalScale() {
        Minecraft mc = Minecraft.getInstance();
        if (mc != null && mc.getWindow() != null && mc.options != null) {
            int normalScale = mc.getWindow().calculateScale(mc.options.guiScale().get(), mc.isEnforceUnicode());
            int optimalScale = getOptimalScale(mc, normalScale);
            if (mc.getWindow().getGuiScale() != optimalScale) {
                mc.getWindow().setGuiScale(optimalScale);
                this.width = mc.getWindow().getGuiScaledWidth();
                this.height = mc.getWindow().getGuiScaledHeight();
            }
        }
    }

    private void restoreGuiScale() {
        Minecraft mc = Minecraft.getInstance();
        if (mc != null && mc.getWindow() != null && mc.options != null) {
            int normalScale = mc.getWindow().calculateScale(mc.options.guiScale().get(), mc.isEnforceUnicode());
            if (mc.getWindow().getGuiScale() != normalScale) {
                mc.getWindow().setGuiScale(normalScale);
            }
        }
    }

    private int getOptimalScale(Minecraft mc, int normalScale) {
        if (mc == null || mc.getWindow() == null) return normalScale;
        Window window = mc.getWindow();
        int fbWidth = window.getWidth();
        int fbHeight = window.getHeight();

        int scale = normalScale;
        while (scale > 1) {
            int scaledW = (int) Math.ceil((double) fbWidth / scale);
            int scaledH = (int) Math.ceil((double) fbHeight / scale);
            if (scaledW >= 640 && scaledH >= 420) {
                break;
            }
            scale--;
        }
        return Math.max(1, scale);
    }
}
