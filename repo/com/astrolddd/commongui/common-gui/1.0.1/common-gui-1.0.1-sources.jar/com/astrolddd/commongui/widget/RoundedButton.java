package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.anim.Anim;
import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.function.Consumer;

public class RoundedButton extends Widget {
    private final Component message;
    private final Consumer<RoundedButton> onPress;
    private boolean pressed = false;
    private final com.astrolddd.commongui.anim.Spring hoverSpring = new com.astrolddd.commongui.anim.Spring(0.0f, com.astrolddd.commongui.anim.Spring.SMOOTH_STIFFNESS, com.astrolddd.commongui.anim.Spring.SMOOTH_DAMPING);
    private final com.astrolddd.commongui.anim.Spring pressSpring = new com.astrolddd.commongui.anim.Spring(0.0f, com.astrolddd.commongui.anim.Spring.SNAPPY_STIFFNESS, com.astrolddd.commongui.anim.Spring.SNAPPY_DAMPING);
    private long lastFrameNanos = 0;

    public RoundedButton(int x, int y, int width, int height, Component message, Consumer<RoundedButton> onPress) {
        super(x, y, width, height);
        this.message = message;
        this.onPress = onPress;
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible) return;
        updateHover(mouseX, mouseY);

        long now = System.nanoTime();
        float dt = lastFrameNanos == 0 ? 0.016f : (float) ((now - lastFrameNanos) / 1_000_000_000.0);
        lastFrameNanos = now;

        hoverSpring.step((hovered && enabled) ? 1.0f : 0.0f, dt);
        pressSpring.step((pressed && hovered && enabled) ? 1.0f : 0.0f, dt);

        float hoverProgress = hoverSpring.getValue();
        float pressProgress = pressSpring.getValue();

        int baseColor = Anim.lerpColor(UiTheme.BTN_IDLE, UiTheme.BTN_HOVER, hoverProgress);
        int bgColor = Anim.lerpColor(baseColor, UiTheme.BTN_PRESSED, pressProgress);
        int textColor = enabled ? UiTheme.TEXT_PRIMARY : UiTheme.TEXT_DISABLED;

        // Pill button background
        Draw.pill(g, x, y, width, height, bgColor);
        // 1px subtle border
        Draw.pillOutline(g, x, y, width, height, 1, UiTheme.BTN_BORDER);

        // Center text or draw vector close icon
        Font font = Minecraft.getInstance().font;
        String str = message.getString();
        if ("✕".equals(str) || "×".equals(str) || "x".equalsIgnoreCase(str)) {
            // Draw pixel-perfect centered vector cross
            int cx = x + width / 2;
            int cy = y + height / 2;
            int s = 3;
            for (int i = -s; i <= s; i++) {
                g.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, textColor);
                g.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, textColor);
            }
        } else {
            Component cleanMsg = UiTheme.text(message);
            int textWidth = font.width(cleanMsg);
            int textX = x + (width - textWidth) / 2;
            int textY = y + (height - 8) / 2;
            g.text(font, cleanMsg, textX, textY, textColor, false);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!enabled || !visible) return false;
        if (isLeftClick(event) && isMouseOver(event.x(), event.y())) {
            this.pressed = true;
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.0F));
            if (onPress != null) {
                onPress.accept(this);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (isLeftClick(event)) {
            this.pressed = false;
        }
        return false;
    }
}
