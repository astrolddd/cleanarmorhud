package com.astrolddd.commongui.screen;

import com.astrolddd.commongui.widget.Widget;

import java.util.List;

/**
 * Represents a single setting entry or row inside a {@link ConfigSection}.
 */
public interface ConfigEntry {
    /**
     * The vertical space allocated for this entry inside the section card.
     */
    int getHeight();

    /**
     * Instantiates and positions the widgets for this entry.
     *
     * @param x     The left content coordinate inside the card.
     * @param y     The top coordinate for this row.
     * @param width The available content width inside the card.
     * @return List of widgets to register for rendering and event handling.
     */
    List<Widget> createWidgets(int x, int y, int width);
}
