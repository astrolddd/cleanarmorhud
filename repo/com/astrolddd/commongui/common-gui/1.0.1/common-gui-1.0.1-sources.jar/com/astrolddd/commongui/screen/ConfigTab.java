package com.astrolddd.commongui.screen;

import com.astrolddd.commongui.widget.Widget;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a single category/tab within {@link BaseConfigScreen}.
 */
public class ConfigTab {
    private final String name;
    private final List<ConfigSection> sections = new ArrayList<>();
    private final List<Widget> standaloneWidgets = new ArrayList<>();

    public ConfigTab(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public List<ConfigSection> getSections() {
        return sections;
    }

    public List<Widget> getStandaloneWidgets() {
        return standaloneWidgets;
    }

    public ConfigSection addSection(String title) {
        return addSection(title, null);
    }

    public ConfigSection addSection(String title, String subtitle) {
        ConfigSection section = new ConfigSection(title, subtitle);
        sections.add(section);
        return section;
    }

    public ConfigTab addWidget(Widget widget) {
        standaloneWidgets.add(widget);
        return this;
    }
}
