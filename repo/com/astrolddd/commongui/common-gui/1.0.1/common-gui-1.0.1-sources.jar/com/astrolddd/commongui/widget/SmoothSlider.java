package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.anim.Anim;
import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Function;

public class SmoothSlider extends Widget {
    private final double min;
    private final double max;
    private final double defaultValue;
    private double value;
    private final Function<Double, String> labelProvider;
    private final Consumer<Double> onChange;

    private boolean dragging = false;
    private float animProgress;
    private float knobScaleAnim = 1.0f;
    private final com.astrolddd.commongui.anim.Spring knobStretchSpring = new com.astrolddd.commongui.anim.Spring(0.0f, 240.0f, 18.0f);
    private long lastFrameNanos = 0;

    public SmoothSlider(int x, int y, int width, int height, double min, double max, double value, double defaultValue,
                        Function<Double, String> labelProvider, Consumer<Double> onChange) {
        super(x, y, width, height);
        this.min = min;
        this.max = max;
        this.value = Math.max(min, Math.min(max, value));
        this.defaultValue = defaultValue;
        this.labelProvider = labelProvider;
        this.onChange = onChange;
        this.animProgress = (float) ((this.value - min) / (max - min));
    }

    public double getValue() {
        return value;
    }

    public void setValue(double val) {
        this.value = Math.max(min, Math.min(max, val));
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible) return;
        updateHover(mouseX, mouseY);

        long now = System.nanoTime();
        float dt = lastFrameNanos == 0 ? 0.016f : (float) ((now - lastFrameNanos) / 1_000_000_000.0);
        lastFrameNanos = now;

        // Smooth knob scale on hover/drag
        float targetKnobScale = (hovered || dragging) ? 1.10f : 1.0f;
        knobScaleAnim += (targetKnobScale - knobScaleAnim) * (1.0f - (float) Math.exp(-22.0f * dt));

        int trackHeight = 6;
        int trackY = y + (height - trackHeight) / 2;

        // Background track
        Draw.pill(g, x, trackY, width, trackHeight, UiTheme.SLIDER_TRACK);

        float targetProgress = (float) ((value - min) / (max - min));
        float diff = targetProgress - animProgress;
        if (Math.abs(diff) < 0.0002f) {
            animProgress = targetProgress;
        } else {
            animProgress += diff * (1.0f - (float) Math.exp(-28.0f * dt));
        }
        float progress = Math.max(0.0f, Math.min(1.0f, animProgress));

        int knobBaseRadius = height / 2 - 2;
        int travelDistance = width - knobBaseRadius * 2;

        // Fluid elastic stretch physics: knob elastically stretches horizontally in the pull direction
        float pull = (targetProgress - animProgress) * travelDistance;
        float targetStretch = Math.max(-6.0f, Math.min(6.0f, pull * 0.40f));
        knobStretchSpring.step(targetStretch, dt);
        float stretch = knobStretchSpring.getValue();

        int fillWidth = Math.max(trackHeight, (int) (width * progress));

        // Filled portion
        Draw.pill(g, x, trackY, fillWidth, trackHeight, UiTheme.SLIDER_FILL);

        // Knob position & geometry with horizontal stretch dynamics
        int knobEffectiveRadius = Math.round(knobBaseRadius * knobScaleAnim);
        int knobCenterX = x + (int) (travelDistance * progress) + knobBaseRadius;
        int knobCenterY = y + height / 2;

        int knobRx = Math.round(knobEffectiveRadius + Math.abs(stretch));
        int knobRy = Math.max(3, Math.round(knobEffectiveRadius - Math.abs(stretch) * 0.35f));

        // Knob soft shadow & pill body
        Draw.softShadow(g, knobCenterX - knobRx, knobCenterY - knobRy,
                knobRx * 2, knobRy * 2, knobRy, 2, 0x40);
        Draw.pill(g, knobCenterX - knobRx, knobCenterY - knobRy,
                knobRx * 2, knobRy * 2, UiTheme.SLIDER_KNOB);

        // Value text
        Font font = Minecraft.getInstance().font;
        String text = labelProvider != null ? labelProvider.apply(value) : String.format(Locale.ROOT, "%.1f", value);
        Component cleanText = UiTheme.text(text);
        int textW = font.width(cleanText);
        int textX = x + width + 8;
        int textY = y + (height - 8) / 2;
        g.text(font, cleanText, textX, textY, UiTheme.TEXT_SECONDARY, false);

        // Value bubble while dragging
        if (dragging) {
            int bubbleW = textW + 8;
            int bubbleH = 16;
            int bubbleX = knobCenterX - bubbleW / 2;
            int bubbleY = y - bubbleH - 4;
            Draw.pill(g, bubbleX, bubbleY, bubbleW, bubbleH, 0xCC2A2A28);
            g.text(font, cleanText, bubbleX + 4, bubbleY + 4, 0xFFFFFFFF, false);
        }
    }

    private void updateFromMouse(double mouseX) {
        int knobBaseRadius = height / 2 - 2;
        double trackStart = x + knobBaseRadius;
        double trackLength = width - knobBaseRadius * 2;
        double progress = Math.max(0.0, Math.min(1.0, (mouseX - trackStart) / trackLength));
        this.value = min + progress * (max - min);
        if (onChange != null) {
            onChange.accept(this.value);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!enabled || !visible) return false;
        if (isLeftClick(event) && isMouseOver(event.x(), event.y())) {
            if (doubleClick) {
                this.value = defaultValue;
                if (onChange != null) onChange.accept(this.value);
                return true;
            }
            this.dragging = true;
            updateFromMouse(event.x());
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (this.dragging) {
            updateFromMouse(event.x());
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (isLeftClick(event)) {
            this.dragging = false;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (isMouseOver(mouseX, mouseY)) {
            double step = (max - min) / 50.0;
            if (verticalAmount > 0) {
                setValue(value + step);
            } else if (verticalAmount < 0) {
                setValue(value - step);
            }
            if (onChange != null) onChange.accept(this.value);
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (focused) {
            double step = (max - min) / 100.0;
            boolean shift = (event.modifiers() & InputConstants.MOD_SHIFT) != 0;
            if (shift) step /= 10.0;

            if (event.key() == InputConstants.KEY_LEFT || event.key() == InputConstants.KEY_DOWN) {
                setValue(value - step);
                if (onChange != null) onChange.accept(this.value);
                return true;
            } else if (event.key() == InputConstants.KEY_RIGHT || event.key() == InputConstants.KEY_UP) {
                setValue(value + step);
                if (onChange != null) onChange.accept(this.value);
                return true;
            }
        }
        return false;
    }
}
