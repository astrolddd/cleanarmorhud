package com.astrolddd.commongui.theme;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.resources.Identifier;

public final class UiTheme {
    private static Identifier fontClean = Identifier.fromNamespaceAndPath("commongui", "segoeui");
    private static FontDescription cleanFontDesc = new FontDescription.Resource(fontClean);

    public static Identifier getFont() {
        return fontClean;
    }

    public static FontDescription getFontDesc() {
        return cleanFontDesc;
    }

    public static void setFont(String fontName) {
        fontClean = Identifier.fromNamespaceAndPath("commongui", fontName);
        cleanFontDesc = new FontDescription.Resource(fontClean);
    }

    public static Component text(String text) {
        if (text == null) return Component.empty();
        return Component.literal(text).withStyle(s -> s.withFont(cleanFontDesc));
    }

    public static Component text(Component component) {
        if (component == null) return Component.empty();
        return Component.literal(component.getString()).withStyle(s -> s.withFont(cleanFontDesc));
    }

    private UiTheme() {}

    private static boolean dark = true;

    // Surfaces & Backdrops
    public static int BACKDROP_SOLID;
    public static int BACKDROP_OVERLAY;
    public static int WINDOW_SURFACE;
    public static int CARD_BG;
    public static int CARD_BORDER;
    public static int MODAL_BORDER;
    public static int SIDEBAR_BG;
    public static int DIVIDER;
    public static int POPUP_BG;
    public static int POPUP_BORDER;

    // Typography Colors
    public static int TEXT_PRIMARY;
    public static int TEXT_SECONDARY;
    public static int TEXT_DISABLED;
    public static int TEXT_WHITE;

    // Interactive Buttons
    public static int BTN_IDLE;
    public static int BTN_BORDER;
    public static int BTN_HOVER;
    public static int BTN_PRESSED;
    public static int TAB_SELECTED;

    // Toggles & Accent
    public static int TOGGLE_ON;
    public static int TOGGLE_OFF;
    public static int ACCENT;
    public static int DANGER;

    // Sliders
    public static int SLIDER_TRACK;
    public static int SLIDER_FILL;
    public static int SLIDER_KNOB;

    // Radii (constants)
    public static final int RADIUS_WINDOW = 18;
    public static final int RADIUS_CARD = 12;
    public static final int RADIUS_INPUT = 10;
    public static final int RADIUS_SMALL = 6;

    static {
        applyDarkPalette();
    }

    public static boolean isDark() {
        return dark;
    }

    public static void setDarkMode(boolean isDark) {
        dark = isDark;
        if (dark) {
            applyDarkPalette();
        } else {
            applyLightPalette();
        }
    }

    public static void toggle() {
        setDarkMode(!dark);
    }

    private static void applyLightPalette() {
        BACKDROP_SOLID = 0xFFF1F5F9;
        BACKDROP_OVERLAY = 0x66000000;
        WINDOW_SURFACE = 0xD0FFFFFF; // clean, crisp semi-translucent frosted white glass (~81% opacity)
        CARD_BG = 0x70F8FAFC;        // clean subtle card layer
        CARD_BORDER = 0x18000000;    // soft 1px card outline
        MODAL_BORDER = 0x1E000000;
        SIDEBAR_BG = 0x55E2E8F0;     // clean cool neutral sidebar tint
        DIVIDER = 0x16000000;
        POPUP_BG = 0xF8FFFFFF;
        POPUP_BORDER = 0x24000000;

        TEXT_PRIMARY = 0xFF0F172A;   // deep slate
        TEXT_SECONDARY = 0xFF64748B; // neutral slate gray
        TEXT_DISABLED = 0xFF94A3B8;
        TEXT_WHITE = 0xFFFFFFFF;

        BTN_IDLE = 0x50FFFFFF;
        BTN_BORDER = 0x1E000000;
        BTN_HOVER = 0x80FFFFFF;
        BTN_PRESSED = 0xA0FFFFFF;
        TAB_SELECTED = 0x1A000000;

        TOGGLE_ON = 0xFF10B981;
        TOGGLE_OFF = 0xFFCBD5E1;
        ACCENT = 0xFF10B981;
        DANGER = 0xFFEF4444;

        SLIDER_TRACK = 0x1E000000;
        SLIDER_FILL = 0xEE10B981;    // vibrant emerald accent (matches toggles, eliminates dirty brown)
        SLIDER_KNOB = 0xFFFFFFFF;
    }

    private static void applyDarkPalette() {
        BACKDROP_SOLID = 0xFF0D0E12;
        BACKDROP_OVERLAY = 0x88000000;
        WINDOW_SURFACE = 0x9E10131A; // sleek semi-translucent dark glass (~62% opacity)
        CARD_BG = 0x18FFFFFF;        // subtle translucent card layer
        CARD_BORDER = 0x20FFFFFF;    // fine 1px soft glass border
        MODAL_BORDER = 0x28FFFFFF;   // top rim highlight
        SIDEBAR_BG = 0x6E0B0D13;     // semi-translucent sidebar inset (~43% opacity)
        DIVIDER = 0x1CFFFFFF;        // crisp subtle divider line
        POPUP_BG = 0xF0141620;       // semi-opaque dark surface
        POPUP_BORDER = 0x33FFFFFF;   // clean crisp border

        TEXT_PRIMARY = 0xFFFFFFFF;
        TEXT_SECONDARY = 0x8CFFFFFF;
        TEXT_DISABLED = 0x40FFFFFF;
        TEXT_WHITE = 0xFFFFFFFF;

        BTN_IDLE = 0x14FFFFFF;
        BTN_BORDER = 0x1AFFFFFF;
        BTN_HOVER = 0x24FFFFFF;
        BTN_PRESSED = 0x33FFFFFF;
        TAB_SELECTED = 0x24FFFFFF;

        TOGGLE_ON = 0xFF43B581;
        TOGGLE_OFF = 0x33FFFFFF;
        ACCENT = 0xFF43B581;
        DANGER = 0xFFFF4F44;

        SLIDER_TRACK = 0x26FFFFFF;
        SLIDER_FILL = 0xEE43B581;
        SLIDER_KNOB = 0xFFFFFFFF;
    }
}
