package com.astrolddd.commongui.anim;

public final class Easing {
    private Easing() {}

    public static float clamp01(float t) {
        return Math.max(0.0f, Math.min(1.0f, t));
    }

    public static float easeOutCubic(float t) {
        float f = 1.0f - clamp01(t);
        return 1.0f - f * f * f;
    }

    public static float easeInOutCubic(float t) {
        float x = clamp01(t);
        return x < 0.5f ? 4.0f * x * x * x : 1.0f - (float) Math.pow(-2.0f * x + 2.0f, 3) / 2.0f;
    }
}
