package com.astrolddd.commongui.draw;

import com.mojang.blaze3d.platform.NativeImage;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.Map;

public final class Draw {
    private static final String MOD_ID = "commongui";
    private static final int SUPERSAMPLE = 4;

    private static final Map<Long, DynamicTexture> TEXTURE_CACHE = new HashMap<>();
    private static final Map<Long, Identifier> ID_CACHE = new HashMap<>();

    private Draw() {}

    /**
     * Draws a filled rounded rectangle with smooth anti-aliased corners using high-DPI supersampling.
     */
    public static void rect(GuiGraphicsExtractor g, int x, int y, int width, int height, int argbColor) {
        g.fill(x, y, x + width, y + height, argbColor);
    }

    public static void roundedRect(GuiGraphicsExtractor g, int x, int y, int width, int height, int radius, int argbColor) {
        if (width <= 0 || height <= 0) return;
        int maxR = Math.min(width, height) / 2;
        int r = Math.max(0, Math.min(radius, maxR));

        if (r <= 0) {
            g.fill(x, y, x + width, y + height, argbColor);
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        double guiScale = mc.getWindow() != null ? mc.getWindow().getGuiScale() : 2.0;
        Identifier circleId = getCircleTexture(r, guiScale);

        if (circleId != null) {
            int d = 2 * r;
            // 4 corners from quarter slices of the circle texture
            // Top-left
            BlitBridge.blit(g, circleId, x, y, 0f, 0f, r, r, d, d, argbColor);
            // Top-right
            BlitBridge.blit(g, circleId, x + width - r, y, (float) r, 0f, r, r, d, d, argbColor);
            // Bottom-left
            BlitBridge.blit(g, circleId, x, y + height - r, 0f, (float) r, r, r, d, d, argbColor);
            // Bottom-right
            BlitBridge.blit(g, circleId, x + width - r, y + height - r, (float) r, (float) r, r, r, d, d, argbColor);

            // Straight edges and center
            if (width > 2 * r) {
                g.fill(x + r, y, x + width - r, y + r, argbColor); // top edge
                g.fill(x + r, y + height - r, x + width - r, y + height, argbColor); // bottom edge
                g.fill(x + r, y + r, x + width - r, y + height - r, argbColor); // center
            }
            if (height > 2 * r) {
                g.fill(x, y + r, x + r, y + height - r, argbColor); // left edge
                g.fill(x + width - r, y + r, x + width, y + height - r, argbColor); // right edge
            }
        } else {
            // Fallback scanline
            scanlineRoundedRect(g, x, y, width, height, r, argbColor);
        }
    }

    /**
     * Draws a rectangle with only left corners smoothly rounded (right side remains flush).
     */
    public static void roundedRectLeft(GuiGraphicsExtractor g, int x, int y, int width, int height, int radius, int argbColor) {
        if (width <= 0 || height <= 0) return;
        int maxR = Math.min(width, height) / 2;
        int r = Math.max(0, Math.min(radius, maxR));

        if (r <= 0) {
            g.fill(x, y, x + width, y + height, argbColor);
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        double guiScale = mc.getWindow() != null ? mc.getWindow().getGuiScale() : 2.0;
        Identifier circleId = getCircleTexture(r, guiScale);

        if (circleId != null) {
            int d = 2 * r;
            // Top-left corner
            BlitBridge.blit(g, circleId, x, y, 0f, 0f, r, r, d, d, argbColor);
            // Bottom-left corner
            BlitBridge.blit(g, circleId, x, y + height - r, 0f, (float) r, r, r, d, d, argbColor);

            // Left straight edge between corners
            if (height > 2 * r) {
                g.fill(x, y + r, x + r, y + height - r, argbColor);
            }
            // Entire remaining block to the right (flush right edge, non-overlapping)
            if (width > r) {
                g.fill(x + r, y, x + width, y + height, argbColor);
            }
        } else {
            g.fill(x, y, x + width, y + height, argbColor);
        }
    }

    /**
     * Draws a rounded outline with smooth anti-aliased corners and uniform border thickness.
     */
    public static void roundedOutline(GuiGraphicsExtractor g, int x, int y, int width, int height, int radius, int thickness, int argbColor) {
        if (width <= 0 || height <= 0 || thickness <= 0) return;
        int maxR = Math.min(width, height) / 2;
        int r = Math.max(0, Math.min(radius, maxR));
        int t = Math.min(thickness, maxR);

        if (r <= 0) {
            outline(g, x, y, width, height, t, argbColor);
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        double guiScale = mc.getWindow() != null ? mc.getWindow().getGuiScale() : 2.0;
        Identifier ringId = getRingTexture(r, t, guiScale);

        if (ringId != null) {
            int d = 2 * r;
            // 4 corners from ring texture
            BlitBridge.blit(g, ringId, x, y, 0f, 0f, r, r, d, d, argbColor);
            BlitBridge.blit(g, ringId, x + width - r, y, (float) r, 0f, r, r, d, d, argbColor);
            BlitBridge.blit(g, ringId, x, y + height - r, 0f, (float) r, r, r, d, d, argbColor);
            BlitBridge.blit(g, ringId, x + width - r, y + height - r, (float) r, (float) r, r, r, d, d, argbColor);

            // 4 straight border lines connecting the corners
            if (width > 2 * r) {
                g.fill(x + r, y, x + width - r, y + t, argbColor); // top
                g.fill(x + r, y + height - t, x + width - r, y + height, argbColor); // bottom
            }
            if (height > 2 * r) {
                g.fill(x, y + r, x + t, y + height - r, argbColor); // left
                g.fill(x + width - t, y + r, x + width, y + height - r, argbColor); // right
            }
        } else {
            outline(g, x, y, width, height, t, argbColor);
        }
    }

    private static void scanlineRoundedRect(GuiGraphicsExtractor g, int x, int y, int width, int height, int radius, int color) {
        float r = Math.max(0, Math.min(radius, Math.min(width, height) / 2f));
        for (int row = 0; row < height; row++) {
            float dy = row < r ? r - row : row > height - r ? row - (height - r) : 0;
            float inset = dy == 0 ? 0 : r - (float) Math.sqrt(Math.max(0, r * r - dy * dy));
            int left = (int) Math.ceil(x + inset);
            int right = (int) Math.floor(x + width - inset);
            if (right > left) {
                g.fill(left, y + row, right, y + row + 1, color);
            }
        }
    }

    public static void outline(GuiGraphicsExtractor g, int x, int y, int width, int height, int thickness, int argbColor) {
        if (width <= 0 || height <= 0 || thickness <= 0) return;
        g.fill(x, y, x + width, y + thickness, argbColor);
        g.fill(x, y + height - thickness, x + width, y + height, argbColor);
        g.fill(x, y + thickness, x + thickness, y + height - thickness, argbColor);
        g.fill(x + width - thickness, y + thickness, x + width, y + height - thickness, argbColor);
    }

    public static void pill(GuiGraphicsExtractor g, int x, int y, int width, int height, int argbColor) {
        roundedRect(g, x, y, width, height, height / 2, argbColor);
    }

    public static void pillOutline(GuiGraphicsExtractor g, int x, int y, int width, int height, int thickness, int argbColor) {
        roundedOutline(g, x, y, width, height, height / 2, thickness, argbColor);
    }

    public static void circle(GuiGraphicsExtractor g, int x, int y, int radius, int argbColor) {
        roundedRect(g, x - radius, y - radius, radius * 2, radius * 2, radius, argbColor);
    }

    /**
     * Soft layered drop shadow.
     */
    public static void softShadow(GuiGraphicsExtractor g, int x, int y, int width, int height, int radius, int blur, int shadowBaseAlpha) {
        if (blur <= 0 || shadowBaseAlpha <= 0) return;
        int steps = Math.min(blur, 4);
        for (int i = steps; i >= 1; i--) {
            int spread = i;
            float factor = (float) (steps - i + 1) / (float) (steps * 2);
            int layerAlpha = Math.round(shadowBaseAlpha * factor);
            if (layerAlpha <= 0) continue;
            int layerColor = (layerAlpha << 24);
            roundedRect(g, x - spread, y - spread + 1, width + 2 * spread, height + 2 * spread, radius + spread, layerColor);
        }
    }

    public static void checkerboard(GuiGraphicsExtractor g, int x, int y, int width, int height, int size) {
        int color1 = UiTheme.isDark() ? 0xFF28282D : 0xFFF2ECE1;
        int color2 = UiTheme.isDark() ? 0xFF1E1E22 : 0xFFE6DED0;
        for (int row = 0; row < height; row += size) {
            for (int col = 0; col < width; col += size) {
                int c = ((row / size) + (col / size)) % 2 == 0 ? color1 : color2;
                int right = Math.min(x + width, x + col + size);
                int bottom = Math.min(y + height, y + row + size);
                g.fill(x + col, y + row, right, bottom, c);
            }
        }
    }

    public static void drawSaturationBrightnessSquare(GuiGraphicsExtractor g, int x, int y, int width, int height, float hue) {
        for (int col = 0; col < width; col++) {
            float sat = (float) col / (float) Math.max(1, width - 1);
            int topRgb = hsbToRgb(hue, sat, 1.0f);
            int colX = x + col;
            g.fillGradient(colX, y, colX + 1, y + height, 0xFF000000 | topRgb, 0xFF000000);
        }
    }

    public static void drawHueBar(GuiGraphicsExtractor g, int x, int y, int width, int height) {
        for (int row = 0; row < height; row++) {
            float hue = (float) row / (float) Math.max(1, height - 1);
            int color = 0xFF000000 | hsbToRgb(hue, 1.0f, 1.0f);
            g.fill(x, y + row, x + width, y + row + 1, color);
        }
    }

    public static int hsbToRgb(float hue, float saturation, float brightness) {
        int r = 0, g = 0, b = 0;
        if (saturation == 0) {
            r = g = b = (int) (brightness * 255.0f + 0.5f);
        } else {
            float h = (hue - (float) Math.floor(hue)) * 6.0f;
            float f = h - (float) Math.floor(h);
            float p = brightness * (1.0f - saturation);
            float q = brightness * (1.0f - saturation * f);
            float t = brightness * (1.0f - (saturation * (1.0f - f)));
            switch ((int) h) {
                case 0 -> { r = Math.round(brightness * 255f); g = Math.round(t * 255f); b = Math.round(p * 255f); }
                case 1 -> { r = Math.round(q * 255f); g = Math.round(brightness * 255f); b = Math.round(p * 255f); }
                case 2 -> { r = Math.round(p * 255f); g = Math.round(brightness * 255f); b = Math.round(t * 255f); }
                case 3 -> { r = Math.round(p * 255f); g = Math.round(q * 255f); b = Math.round(brightness * 255f); }
                case 4 -> { r = Math.round(t * 255f); g = Math.round(p * 255f); b = Math.round(brightness * 255f); }
                case 5 -> { r = Math.round(brightness * 255f); g = Math.round(p * 255f); b = Math.round(q * 255f); }
            }
        }
        return (r << 16) | (g << 8) | b;
    }

    public static float[] rgbToHsb(int rgb) {
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        int cmax = Math.max(r, Math.max(g, b));
        int cmin = Math.min(r, Math.min(g, b));
        float brightness = ((float) cmax) / 255.0f;
        float saturation;
        if (cmax != 0) {
            saturation = ((float) (cmax - cmin)) / ((float) cmax);
        } else {
            saturation = 0;
        }
        float hue;
        if (saturation == 0) {
            hue = 0;
        } else {
            float redc = ((float) (cmax - r)) / ((float) (cmax - cmin));
            float greenc = ((float) (cmax - g)) / ((float) (cmax - cmin));
            float bluec = ((float) (cmax - b)) / ((float) (cmax - cmin));
            if (r == cmax) hue = bluec - greenc;
            else if (g == cmax) hue = 2.0f + redc - bluec;
            else hue = 4.0f + greenc - redc;
            hue = hue / 6.0f;
            if (hue < 0) hue = hue + 1.0f;
        }
        return new float[]{hue, saturation, brightness};
    }

    public static void clearTextures() {
        Minecraft mc = Minecraft.getInstance();
        for (var entry : TEXTURE_CACHE.entrySet()) {
            Identifier id = ID_CACHE.get(entry.getKey());
            if (id != null && mc.getTextureManager() != null) {
                mc.getTextureManager().release(id);
            }
            entry.getValue().close();
        }
        TEXTURE_CACHE.clear();
        ID_CACHE.clear();
    }

    private static synchronized Identifier getCircleTexture(int radius, double guiScale) {
        long key = (((long) radius) << 32) | (long) Math.round(guiScale * 100);
        if (ID_CACHE.containsKey(key)) {
            return ID_CACHE.get(key);
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.getTextureManager() == null) return null;

        int physicalRadius = Math.max(1, (int) Math.round(radius * guiScale));
        int physicalDim = physicalRadius * 2;

        try {
            NativeImage image = new NativeImage(physicalDim, physicalDim, false);
            double center = physicalRadius;
            double rSq = center * center;

            for (int y = 0; y < physicalDim; y++) {
                for (int x = 0; x < physicalDim; x++) {
                    int inside = 0;
                    for (int sy = 0; sy < SUPERSAMPLE; sy++) {
                        for (int sx = 0; sx < SUPERSAMPLE; sx++) {
                            double px = x + (sx + 0.5) / SUPERSAMPLE;
                            double py = y + (sy + 0.5) / SUPERSAMPLE;
                            double dx = px - center;
                            double dy = py - center;
                            if (dx * dx + dy * dy <= rSq) {
                                inside++;
                            }
                        }
                    }
                    int alpha = (int) Math.round((inside / (double) (SUPERSAMPLE * SUPERSAMPLE)) * 255.0);
                    image.setPixelABGR(x, y, (alpha << 24) | 0x00FFFFFF);
                }
            }

            Identifier id = Identifier.fromNamespaceAndPath(MOD_ID, "circle_" + radius + "_" + Math.round(guiScale * 100));
            DynamicTexture texture = new DynamicTexture(() -> id.toString(), image);
            texture.upload();
            mc.getTextureManager().register(id, texture);

            TEXTURE_CACHE.put(key, texture);
            ID_CACHE.put(key, id);
            return id;
        } catch (Exception e) {
            return null;
        }
    }

    private static synchronized Identifier getRingTexture(int radius, int thickness, double guiScale) {
        long key = (1L << 60) | (((long) radius) << 32) | (((long) thickness) << 16) | (long) Math.round(guiScale * 100);
        if (ID_CACHE.containsKey(key)) {
            return ID_CACHE.get(key);
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.getTextureManager() == null) return null;

        int physicalRadius = Math.max(1, (int) Math.round(radius * guiScale));
        int physicalDim = physicalRadius * 2;
        int physicalThickness = Math.max(1, (int) Math.round(thickness * guiScale));

        try {
            NativeImage image = new NativeImage(physicalDim, physicalDim, false);
            double center = physicalRadius;
            double outerRSq = center * center;
            double innerR = Math.max(0, center - physicalThickness);
            double innerRSq = innerR * innerR;

            for (int y = 0; y < physicalDim; y++) {
                for (int x = 0; x < physicalDim; x++) {
                    int inside = 0;
                    for (int sy = 0; sy < SUPERSAMPLE; sy++) {
                        for (int sx = 0; sx < SUPERSAMPLE; sx++) {
                            double px = x + (sx + 0.5) / SUPERSAMPLE;
                            double py = y + (sy + 0.5) / SUPERSAMPLE;
                            double dx = px - center;
                            double dy = py - center;
                            double distSq = dx * dx + dy * dy;
                            if (distSq <= outerRSq && distSq >= innerRSq) {
                                inside++;
                            }
                        }
                    }
                    int alpha = (int) Math.round((inside / (double) (SUPERSAMPLE * SUPERSAMPLE)) * 255.0);
                    image.setPixelABGR(x, y, (alpha << 24) | 0x00FFFFFF);
                }
            }

            Identifier id = Identifier.fromNamespaceAndPath(MOD_ID, "ring_" + radius + "_" + thickness + "_" + Math.round(guiScale * 100));
            DynamicTexture texture = new DynamicTexture(() -> id.toString(), image);
            texture.upload();
            mc.getTextureManager().register(id, texture);

            TEXTURE_CACHE.put(key, texture);
            ID_CACHE.put(key, id);
            return id;
        } catch (Exception e) {
            return null;
        }
    }
}
