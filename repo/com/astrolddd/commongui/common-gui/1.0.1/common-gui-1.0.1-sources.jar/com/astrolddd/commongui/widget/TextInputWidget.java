package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;

import java.util.function.Consumer;
import java.util.function.Predicate;

public class TextInputWidget extends Widget {
    private String text;
    private final String placeholder;
    private int cursorPosition;
    private final Predicate<String> validator;
    private final Consumer<String> onChange;
    private boolean valid = true;

    public TextInputWidget(int x, int y, int width, int height, String initialText, String placeholder,
                           Predicate<String> validator, Consumer<String> onChange) {
        super(x, y, width, height);
        this.text = initialText != null ? initialText : "";
        this.placeholder = placeholder != null ? placeholder : "";
        this.cursorPosition = this.text.length();
        this.validator = validator;
        this.onChange = onChange;
        if (validator != null) {
            this.valid = validator.test(this.text);
        }
    }

    public String getText() {
        return text;
    }

    public void setText(String newText) {
        this.text = newText != null ? newText : "";
        this.cursorPosition = Math.max(0, Math.min(cursorPosition, this.text.length()));
        if (validator != null) {
            this.valid = validator.test(this.text);
        }
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible) return;
        updateHover(mouseX, mouseY);

        int bgColor = UiTheme.CARD_BG;
        int borderColor = !valid
                ? UiTheme.DANGER
                : (focused ? UiTheme.TEXT_PRIMARY : UiTheme.BTN_BORDER);

        Draw.roundedRect(g, x, y, width, height, UiTheme.RADIUS_INPUT, bgColor);
        Draw.roundedOutline(g, x, y, width, height, UiTheme.RADIUS_INPUT, 1, borderColor);

        Font font = Minecraft.getInstance().font;
        int textY = y + (height - 8) / 2;
        int textX = x + 8;

        if (text.isEmpty() && !focused) {
            g.text(font, UiTheme.text(placeholder), textX, textY, UiTheme.TEXT_DISABLED, false);
        } else {
            g.text(font, UiTheme.text(text), textX, textY, UiTheme.TEXT_PRIMARY, false);
        }

        // Caret blinking (every 500ms)
        if (focused && (System.currentTimeMillis() / 500) % 2 == 0) {
            String beforeCursor = text.substring(0, Math.min(cursorPosition, text.length()));
            int caretX = textX + font.width(UiTheme.text(beforeCursor));
            g.fill(caretX, textY - 1, caretX + 1, textY + 9, UiTheme.TEXT_PRIMARY);
        }
    }

    public void setFocused(boolean focused) {
        if (this.focused != focused) {
            this.focused = focused;
            try {
                Minecraft mc = Minecraft.getInstance();
                net.minecraft.client.gui.screens.Screen screen = null;
                try {
                    screen = (net.minecraft.client.gui.screens.Screen) mc.gui.getClass().getMethod("screen").invoke(mc.gui);
                } catch (Throwable t) {
                    try {
                        screen = (net.minecraft.client.gui.screens.Screen) mc.getClass().getField("screen").get(mc);
                    } catch (Throwable ignored) {}
                }
                try {
                    mc.getClass().getMethod("onTextInputFocusChange", net.minecraft.client.gui.components.events.GuiEventListener.class, boolean.class)
                            .invoke(mc, screen, focused);
                } catch (Throwable t1) {
                    try {
                        mc.getClass().getMethod("onTextInputFocusChange", net.minecraft.client.gui.screens.Screen.class, boolean.class)
                                .invoke(mc, screen, focused);
                    } catch (Throwable ignored) {}
                }
            } catch (Throwable ignored) {}
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!enabled || !visible) return false;
        if (isLeftClick(event)) {
            boolean clickedInside = isMouseOver(event.x(), event.y());
            setFocused(clickedInside);
            if (focused) {
                // Approximate cursor position from click X
                Font font = Minecraft.getInstance().font;
                int clickRelX = (int) event.x() - (x + 8);
                int pos = 0;
                for (int i = 0; i <= text.length(); i++) {
                    if (font.width(text.substring(0, i)) <= clickRelX) {
                        pos = i;
                    }
                }
                this.cursorPosition = pos;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (!focused || !enabled) return false;
        if (event.isAllowedChatCharacter()) {
            insertText(event.codepointAsString());
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (!focused || !enabled) return false;
        int key = event.key();
        int keycode = -1;
        try {
            keycode = (int) event.getClass().getMethod("keycode").invoke(event);
        } catch (Throwable ignored) {}

        boolean isCtrl = (event.modifiers() & 2) != 0 || (event.modifiers() & 192) != 0 || (event.modifiers() & 8) != 0;
        try {
            isCtrl = isCtrl || event.hasControlDown();
        } catch (Throwable ignored) {}

        boolean isEnter = false;
        try { isEnter = event.isConfirmation(); } catch (Throwable ignored) {}
        isEnter = isEnter || key == 257 || key == 335 || key == 40 || key == 88 || key == 13 || key == 1073741912 || keycode == 13 || keycode == 1073741912;

        boolean isEscape = false;
        try { isEscape = event.isEscape(); } catch (Throwable ignored) {}
        isEscape = isEscape || key == 256 || key == 41 || key == 27 || keycode == 27;

        boolean isBackspace = (key == 259 || key == 42 || key == 8 || keycode == 8 || keycode == 42 || keycode == 259);
        boolean isDelete = (key == 261 || key == 76 || key == 127 || keycode == 127 || keycode == 76 || keycode == 261);

        boolean isLeft = false;
        try { isLeft = event.isLeft(); } catch (Throwable ignored) {}
        isLeft = isLeft || key == 263 || key == 80 || key == 1073741904 || keycode == 1073741904;

        boolean isRight = false;
        try { isRight = event.isRight(); } catch (Throwable ignored) {}
        isRight = isRight || key == 262 || key == 79 || key == 1073741903 || keycode == 1073741903;

        boolean isHome = key == 268 || key == 74 || key == 1073741898 || keycode == 1073741898;
        boolean isEnd = key == 269 || key == 77 || key == 1073741901 || keycode == 1073741901;

        boolean isPaste = false;
        try { isPaste = event.isPaste(); } catch (Throwable ignored) {}
        isPaste = isPaste || (isCtrl && (key == 86 || key == 25 || key == 118 || keycode == 118));

        cursorPosition = Math.max(0, Math.min(cursorPosition, text.length()));

        if (isEnter || isEscape) {
            setFocused(false);
            return true;
        } else if (isBackspace) {
            if (cursorPosition > 0 && !text.isEmpty()) {
                text = text.substring(0, cursorPosition - 1) + text.substring(cursorPosition);
                cursorPosition--;
                handleTextUpdated();
            }
            return true;
        } else if (isDelete) {
            if (cursorPosition < text.length()) {
                text = text.substring(0, cursorPosition) + text.substring(cursorPosition + 1);
                handleTextUpdated();
            }
            return true;
        } else if (isLeft) {
            if (cursorPosition > 0) cursorPosition--;
            return true;
        } else if (isRight) {
            if (cursorPosition < text.length()) cursorPosition++;
            return true;
        } else if (isHome) {
            cursorPosition = 0;
            return true;
        } else if (isEnd) {
            cursorPosition = text.length();
            return true;
        } else if (isPaste) {
            String clipboard = Minecraft.getInstance().keyboardHandler.getClipboard();
            if (clipboard != null && !clipboard.isEmpty()) {
                insertText(clipboard);
            }
            return true;
        }
        return false;
    }

    private void insertText(String str) {
        if (str == null || str.isEmpty()) return;
        cursorPosition = Math.max(0, Math.min(cursorPosition, text.length()));
        text = text.substring(0, cursorPosition) + str + text.substring(cursorPosition);
        cursorPosition += str.length();
        handleTextUpdated();
    }

    private void handleTextUpdated() {
        if (validator != null) {
            valid = validator.test(text);
        }
        if (onChange != null) {
            onChange.accept(text);
        }
    }
}
