package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.anim.Anim;
import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;

import java.util.List;
import java.util.function.Consumer;

public class SegmentedControl<T> extends Widget {
    public static record Segment<T>(T value, String label) {}

    private final List<Segment<T>> segments;
    private T selectedValue;
    private final Consumer<T> onSelect;
    private final com.astrolddd.commongui.anim.Spring indexSpring;
    private long lastFrameNanos = 0;

    public SegmentedControl(int x, int y, int width, int height, List<Segment<T>> segments, T initialValue, Consumer<T> onSelect) {
        super(x, y, width, height);
        this.segments = segments;
        this.selectedValue = initialValue;
        this.onSelect = onSelect;

        int initialIdx = 0;
        for (int i = 0; i < segments.size(); i++) {
            if (segments.get(i).value().equals(initialValue)) {
                initialIdx = i;
                break;
            }
        }
        this.indexSpring = new com.astrolddd.commongui.anim.Spring(initialIdx, 280.0f, 24.0f);
    }

    public T getSelectedValue() {
        return selectedValue;
    }

    public void setSelectedValue(T val) {
        this.selectedValue = val;
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible || segments.isEmpty()) return;
        updateHover(mouseX, mouseY);

        long now = System.nanoTime();
        float dt = lastFrameNanos == 0 ? 0.016f : (float) ((now - lastFrameNanos) / 1_000_000_000.0);
        lastFrameNanos = now;

        int targetIdx = 0;
        for (int i = 0; i < segments.size(); i++) {
            if (segments.get(i).value().equals(selectedValue)) {
                targetIdx = i;
                break;
            }
        }
        indexSpring.step(targetIdx, dt);
        float animIdx = indexSpring.getValue();

        // Track background
        Draw.pill(g, x, y, width, height, UiTheme.SLIDER_TRACK);

        float segmentW = (float) width / segments.size();

        // Gliding indicator pill with soft shadow
        float pillX = x + animIdx * segmentW + 2;
        int pillW = Math.max(4, Math.round(segmentW - 4));
        int pillH = height - 4;
        Draw.softShadow(g, Math.round(pillX), y + 2, pillW, pillH, pillH / 2, 2, 0x30);
        Draw.pill(g, Math.round(pillX), y + 2, pillW, pillH, UiTheme.CARD_BG);

        Font font = Minecraft.getInstance().font;
        for (int i = 0; i < segments.size(); i++) {
            Segment<T> seg = segments.get(i);
            float segCenterX = x + (i + 0.5f) * segmentW;
            Component cleanLabel = UiTheme.text(seg.label());
            int textW = font.width(cleanLabel);
            int textX = Math.round(segCenterX - textW / 2.0f);
            int textY = y + (height - 8) / 2;

            float distFromPill = Math.abs(animIdx - i);
            float highlight = Math.max(0.0f, 1.0f - distFromPill);
            int textColor = Anim.lerpColor(UiTheme.TEXT_SECONDARY, UiTheme.TEXT_PRIMARY, highlight);

            g.text(font, cleanLabel, textX, textY, textColor, false);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!enabled || !visible || segments.isEmpty()) return false;
        if (isLeftClick(event) && isMouseOver(event.x(), event.y())) {
            int segmentW = width / segments.size();
            int index = (int) ((event.x() - x) / segmentW);
            if (index >= 0 && index < segments.size()) {
                this.selectedValue = segments.get(index).value();
                Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.0F));
                if (onSelect != null) {
                    onSelect.accept(this.selectedValue);
                }
                return true;
            }
        }
        return false;
    }
}
