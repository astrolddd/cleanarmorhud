package com.astrolddd.commongui.draw;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Cross-version blit bridge that dynamically binds to Minecraft's GUI_TEXTURED pipeline
 * and GuiGraphicsExtractor.blit method.
 *
 * This enables common-gui to seamlessly run on:
 * - Minecraft 26.1 & 26.2 (where RenderPipeline is in com.mojang.blaze3d.pipeline)
 * - Minecraft 26.3+ (where RenderPipeline was migrated to com.mojang.renderpearl.api.pipeline)
 * without java.lang.NoSuchFieldError or NoSuchMethodError.
 */
public final class BlitBridge {
    private static final Object GUI_TEXTURED;
    private static final MethodHandle BLIT_11;
    private static final MethodHandle BLIT_13;

    static {
        try {
            Field field = RenderPipelines.class.getField("GUI_TEXTURED");
            GUI_TEXTURED = field.get(null);
            Class<?> pipelineClass = field.getType();

            Method m11 = GuiGraphicsExtractor.class.getMethod("blit",
                pipelineClass, Identifier.class,
                int.class, int.class, float.class, float.class,
                int.class, int.class, int.class, int.class, int.class);
            BLIT_11 = MethodHandles.publicLookup().unreflect(m11);

            Method m13 = GuiGraphicsExtractor.class.getMethod("blit",
                pipelineClass, Identifier.class,
                int.class, int.class, float.class, float.class,
                int.class, int.class, int.class, int.class, int.class, int.class, int.class);
            BLIT_13 = MethodHandles.publicLookup().unreflect(m13);
        } catch (Throwable t) {
            throw new ExceptionInInitializerError(t);
        }
    }

    private BlitBridge() {}

    public static void blit(GuiGraphicsExtractor g, Identifier id, int x, int y, float u, float v, int width, int height, int texW, int texH, int color) {
        try {
            BLIT_11.invoke(g, GUI_TEXTURED, id, x, y, u, v, width, height, texW, texH, color);
        } catch (Throwable t) {
            throw new RuntimeException("Failed to invoke blit (11 args)", t);
        }
    }

    public static void blit(GuiGraphicsExtractor g, Identifier id, int x, int y, float u, float v, int width, int height, int uWidth, int vHeight, int texW, int texH, int color) {
        try {
            BLIT_13.invoke(g, GUI_TEXTURED, id, x, y, u, v, width, height, uWidth, vHeight, texW, texH, color);
        } catch (Throwable t) {
            throw new RuntimeException("Failed to invoke blit (13 args)", t);
        }
    }
}
