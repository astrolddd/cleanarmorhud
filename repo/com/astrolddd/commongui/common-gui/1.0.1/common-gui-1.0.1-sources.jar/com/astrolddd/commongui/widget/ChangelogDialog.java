package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import com.astrolddd.commongui.update.UpdateChecker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class ChangelogDialog {
    private final String modTitle;
    private final UpdateChecker updateChecker;
    private final List<String> formattedLines = new ArrayList<>();
    private final CloseButton closeBtn;
    private final RoundedButton doneBtn;
    private final RoundedButton downloadBtn;
    private boolean active = false;

    private int dialogX, dialogY, dialogW = 420, dialogH = 300;
    private float scrollY = 0.0f;
    private float maxScroll = 0.0f;

    public ChangelogDialog(String modTitle, UpdateChecker updateChecker) {
        this.modTitle = modTitle;
        this.updateChecker = updateChecker;

        this.closeBtn = new CloseButton(0, 0, 18, b -> this.active = false);
        this.doneBtn = new RoundedButton(0, 0, 80, 24, Component.literal("Close"), b -> this.active = false);
        this.downloadBtn = new RoundedButton(0, 0, 120, 24, Component.literal("Modrinth Page"), b -> {
            String url = updateChecker != null ? updateChecker.getDownloadUrl() : null;
            if (url != null && !url.isEmpty()) {
                UpdateChecker.openUrl(url);
            }
        });
    }

    public boolean isActive() {
        return active;
    }

    public void show() {
        this.active = true;
        this.scrollY = 0.0f;
        prepareLines();
    }

    public void close() {
        this.active = false;
    }

    private void prepareLines() {
        formattedLines.clear();
        String raw = updateChecker != null ? updateChecker.getChangelog() : "";
        if (raw == null || raw.isBlank()) {
            return; // Keep completely empty when there are no changes as requested
        }

        String[] split = raw.split("\\R");
        for (String line : split) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) {
                formattedLines.add("");
            } else if (trimmed.startsWith("#")) {
                formattedLines.add(trimmed.replaceAll("^#+\\s*", ""));
            } else if (trimmed.startsWith("-") || trimmed.startsWith("*")) {
                formattedLines.add(" • " + trimmed.substring(1).trim());
            } else {
                formattedLines.add(trimmed);
            }
        }
    }

    public void render(GuiGraphicsExtractor g, int screenWidth, int screenHeight, int mouseX, int mouseY, float delta) {
        if (!active) return;

        // Semi-transparent dim backdrop
        g.fill(0, 0, screenWidth, screenHeight, 0x90000000);

        dialogX = (screenWidth - dialogW) / 2;
        dialogY = (screenHeight - dialogH) / 2;

        // Outer semi-opaque panel with deep shadow & crisp border
        Draw.softShadow(g, dialogX, dialogY, dialogW, dialogH, UiTheme.RADIUS_CARD, 6, 0x80);
        Draw.roundedRect(g, dialogX, dialogY, dialogW, dialogH, UiTheme.RADIUS_CARD, UiTheme.POPUP_BG);
        Draw.roundedOutline(g, dialogX, dialogY, dialogW, dialogH, UiTheme.RADIUS_CARD, 1, UiTheme.POPUP_BORDER);

        // Header bar background & divider
        int headerBarBg = UiTheme.isDark() ? 0x2A000000 : 0x0C000000;
        Draw.roundedRect(g, dialogX, dialogY, dialogW, 40, UiTheme.RADIUS_CARD, headerBarBg);
        g.fill(dialogX, dialogY + 39, dialogX + dialogW, dialogY + 40, UiTheme.DIVIDER);

        Font font = Minecraft.getInstance().font;

        // Header Title
        Component titleComp = UiTheme.text(modTitle + " Changelog");
        g.text(font, titleComp, dialogX + 16, dialogY + 14, UiTheme.TEXT_PRIMARY, false);

        // Version badge pill
        String ver = updateChecker != null ? updateChecker.latestVersion() : "1.0.0";
        boolean hasUpdate = updateChecker != null && updateChecker.isUpdateAvailable();
        String badgeText = "v" + ver + (hasUpdate ? " (Update Available)" : " (Latest)");
        int badgeW = font.width(badgeText) + 8;
        int badgeX = dialogX + 16 + font.width(titleComp) + 8;
        int badgeY = dialogY + 12;
        int badgeBg = hasUpdate ? (UiTheme.isDark() ? 0x4410B981 : 0x3010B981) : (UiTheme.isDark() ? 0x3364748B : 0x20000000);
        int badgeColor = hasUpdate ? (UiTheme.isDark() ? 0xFF34D399 : 0xFF059669) : (UiTheme.isDark() ? 0xFFCBD5E1 : 0xFF475569);
        Draw.pill(g, badgeX, badgeY, badgeW, 14, badgeBg);
        g.text(font, UiTheme.text(badgeText), badgeX + 4, badgeY + 3, badgeColor, false);

        // Close button in header
        closeBtn.setX(dialogX + dialogW - 26);
        closeBtn.setY(dialogY + 10);
        closeBtn.extractWidgetRenderState(g, mouseX, mouseY, delta);

        // Content Scrollable Area
        int contentX = dialogX + 18;
        int contentY = dialogY + 48;
        int contentW = dialogW - 36;
        int contentH = dialogH - 48 - 44;

        int lineHeight = 13;
        int totalTextH = formattedLines.size() * lineHeight + 8;
        maxScroll = Math.max(0.0f, totalTextH - contentH);

        g.enableScissor(contentX, contentY, contentX + contentW, contentY + contentH);

        int titleColor = UiTheme.isDark() ? 0xFFFFFFFF : 0xFF1E293B;
        int textColor = UiTheme.isDark() ? 0xFFCBD5E1 : 0xFF334155;
        int bulletColor = UiTheme.isDark() ? 0xFFF1F5F9 : 0xFF0F172A;
        int subColor = UiTheme.isDark() ? 0xFF94A3B8 : 0xFF64748B;

        int textY = contentY + 4 - Math.round(scrollY); // 4px padding so top line is never clipped by scissor
        for (String line : formattedLines) {
            if (textY + 12 >= contentY && textY <= contentY + contentH) {
                if (!line.isEmpty()) {
                    int col;
                    if (line.startsWith(" •")) {
                        col = bulletColor;
                    } else if (line.startsWith("v") || line.startsWith("Version") || line.contains("Highlights") || line.contains("Changelog")) {
                        col = titleColor;
                    } else if (line.startsWith("Note:") || line.startsWith("Visit")) {
                        col = subColor;
                    } else {
                        col = textColor;
                    }
                    g.text(font, UiTheme.text(line), contentX, textY, col, false);
                }
            }
            textY += lineHeight;
        }

        g.disableScissor();

        // Scrollbar
        if (maxScroll > 0) {
            int scrollTrackX = contentX + contentW - 4;
            int scrollTrackY = contentY;
            int scrollTrackH = contentH;
            int thumbH = Math.max(16, (int) ((float) contentH / totalTextH * scrollTrackH));
            int thumbY = scrollTrackY + (int) (scrollY / maxScroll * (scrollTrackH - thumbH));
            int trackColor = UiTheme.isDark() ? 0x20FFFFFF : 0x18000000;
            int thumbColor = UiTheme.isDark() ? 0x60FFFFFF : 0x50000000;
            Draw.pill(g, scrollTrackX, scrollTrackY, 3, scrollTrackH, trackColor);
            Draw.pill(g, scrollTrackX, thumbY, 3, thumbH, thumbColor);
        }

        // Footer divider and buttons
        g.fill(dialogX, dialogY + dialogH - 42, dialogX + dialogW, dialogY + dialogH - 41, UiTheme.DIVIDER);
        int btnY = dialogY + dialogH - 34;
        downloadBtn.setX(dialogX + 16);
        downloadBtn.setY(btnY);
        downloadBtn.extractWidgetRenderState(g, mouseX, mouseY, delta);

        doneBtn.setX(dialogX + dialogW - 96);
        doneBtn.setY(btnY);
        doneBtn.extractWidgetRenderState(g, mouseX, mouseY, delta);
    }

    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!active) return false;
        if (closeBtn.mouseClicked(event, doubleClick)) return true;
        if (doneBtn.mouseClicked(event, doubleClick)) return true;
        if (downloadBtn.mouseClicked(event, doubleClick)) return true;
        return true;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!active) return false;
        scrollY = Math.max(0.0f, Math.min(maxScroll, scrollY - (float) verticalAmount * 18.0f));
        return true;
    }
}
