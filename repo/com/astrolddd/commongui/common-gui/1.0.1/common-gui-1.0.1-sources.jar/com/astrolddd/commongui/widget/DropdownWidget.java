package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.anim.Anim;
import com.astrolddd.commongui.anim.Spring;
import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

import java.util.List;
import java.util.function.Consumer;

public class DropdownWidget<T> extends Widget {
    public static record DropdownItem<T>(T value, String label, String fontId) {}

    private final List<DropdownItem<T>> items;
    private DropdownItem<T> selected;
    private final Consumer<T> onSelect;
    private boolean open = false;
    private int scrollOffset = 0;
    private static final int ITEM_HEIGHT = 20;
    private static final int MAX_VISIBLE_ITEMS = 6;

    private final Spring hoverSpring = new Spring(0.0f, Spring.SMOOTH_STIFFNESS, Spring.SMOOTH_DAMPING);
    private long lastFrameNanos = 0;

    public DropdownWidget(int x, int y, int width, int height, List<DropdownItem<T>> items, T selectedValue, Consumer<T> onSelect) {
        super(x, y, width, height);
        this.items = items;
        this.onSelect = onSelect;
        this.selected = items.stream().filter(i -> i.value().equals(selectedValue)).findFirst().orElse(!items.isEmpty() ? items.get(0) : null);
    }

    public T getSelectedValue() {
        return selected != null ? selected.value() : null;
    }

    public void setSelectedValue(T val) {
        this.selected = items.stream().filter(i -> i.value().equals(val)).findFirst().orElse(selected);
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible) return;
        updateHover(mouseX, mouseY);

        long now = System.nanoTime();
        float dt = lastFrameNanos == 0 ? 0.016f : (float) ((now - lastFrameNanos) / 1_000_000_000.0);
        lastFrameNanos = now;

        hoverSpring.step((hovered && enabled) ? 1.0f : 0.0f, dt);
        float hov = hoverSpring.getValue();

        // Main closed dropdown field
        int bgColor = Anim.lerpColor(UiTheme.BTN_IDLE, UiTheme.BTN_HOVER, hov);
        Draw.roundedRect(g, x, y, width, height, UiTheme.RADIUS_INPUT, bgColor);
        Draw.roundedOutline(g, x, y, width, height, UiTheme.RADIUS_INPUT, 1, UiTheme.BTN_BORDER);

        Font font = Minecraft.getInstance().font;
        String text = selected != null ? selected.label() : "Select...";
        int textY = y + (height - 8) / 2;

        if (selected != null && selected.fontId() != null && !selected.fontId().isBlank() && !"minecraft:default".equals(selected.fontId())) {
            Identifier fId = Identifier.tryParse(selected.fontId());
            Style style = fId != null ? Style.EMPTY.withFont(new FontDescription.Resource(fId)) : Style.EMPTY;
            g.text(font, Component.literal(text).withStyle(style), x + 8, textY, UiTheme.TEXT_PRIMARY, false);
        } else {
            g.text(font, UiTheme.text(text), x + 8, textY, UiTheme.TEXT_PRIMARY, false);
        }

        // Sleek vector chevron arrow
        int arrowColor = Anim.lerpColor(UiTheme.TEXT_SECONDARY, UiTheme.TEXT_PRIMARY, hov);
        int cx = x + width - 14;
        int cy = y + height / 2;
        if (open) {
            // Chevron pointing upwards
            g.fill(cx - 3, cy + 1, cx - 2, cy + 2, arrowColor);
            g.fill(cx - 2, cy,     cx - 1, cy + 1, arrowColor);
            g.fill(cx - 1, cy - 1, cx,     cy,     arrowColor);
            g.fill(cx,     cy - 1, cx + 1, cy,     arrowColor);
            g.fill(cx + 1, cy,     cx + 2, cy + 1, arrowColor);
            g.fill(cx + 2, cy + 1, cx + 3, cy + 2, arrowColor);
        } else {
            // Chevron pointing downwards
            g.fill(cx - 3, cy - 2, cx - 2, cy - 1, arrowColor);
            g.fill(cx - 2, cy - 1, cx - 1, cy,     arrowColor);
            g.fill(cx - 1, cy,     cx,     cy + 1, arrowColor);
            g.fill(cx,     cy,     cx + 1, cy + 1, arrowColor);
            g.fill(cx + 1, cy - 1, cx + 2, cy,     arrowColor);
            g.fill(cx + 2, cy - 2, cx + 3, cy - 1, arrowColor);
        }
    }

    /**
     * Renders the popup menu in the final overlay pass.
     */
    public void extractPopupRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!open || !visible) return;

        int popupHeight = Math.min(items.size(), MAX_VISIBLE_ITEMS) * ITEM_HEIGHT + 4;
        int popupY = y + height + 2;

        // Shadow & popup card
        Draw.softShadow(g, x, popupY, width, popupHeight, UiTheme.RADIUS_INPUT, 4, 0x70);
        Draw.roundedRect(g, x, popupY, width, popupHeight, UiTheme.RADIUS_INPUT, UiTheme.POPUP_BG);
        Draw.roundedOutline(g, x, popupY, width, popupHeight, UiTheme.RADIUS_INPUT, 1, UiTheme.POPUP_BORDER);

        Font font = Minecraft.getInstance().font;
        g.enableScissor(x, popupY + 2, x + width, popupY + popupHeight - 2);

        int renderY = popupY + 2 - scrollOffset;
        for (int i = 0; i < items.size(); i++) {
            DropdownItem<T> item = items.get(i);
            int rowY = renderY + i * ITEM_HEIGHT;
            if (rowY + ITEM_HEIGHT < popupY || rowY > popupY + popupHeight) continue;

            boolean rowHovered = mouseX >= x && mouseX < x + width && mouseY >= rowY && mouseY < rowY + ITEM_HEIGHT;
            boolean isCurrent = selected != null && selected.value().equals(item.value());

            if (rowHovered || isCurrent) {
                int rowBg = isCurrent ? UiTheme.TAB_SELECTED : UiTheme.BTN_HOVER;
                Draw.roundedRect(g, x + 2, rowY, width - 4, ITEM_HEIGHT, UiTheme.RADIUS_SMALL, rowBg);
            }

            int textY = rowY + (ITEM_HEIGHT - 8) / 2;
            int textColor = isCurrent ? UiTheme.TEXT_PRIMARY : UiTheme.TEXT_SECONDARY;

            // Live font preview: each row renders in its own font if specified
            if (item.fontId() != null && !item.fontId().isBlank() && !"minecraft:default".equals(item.fontId())) {
                Identifier fId = Identifier.tryParse(item.fontId());
                Style style = fId != null ? Style.EMPTY.withFont(new FontDescription.Resource(fId)) : Style.EMPTY;
                g.text(font, Component.literal(item.label()).withStyle(style), x + 8, textY, textColor, false);
            } else {
                g.text(font, UiTheme.text(item.label()), x + 8, textY, textColor, false);
            }
        }

        g.disableScissor();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!enabled || !visible) return false;
        double mx = event.x();
        double my = event.y();

        if (isLeftClick(event)) {
            // Main field click
            if (isMouseOver(mx, my)) {
                this.open = !this.open;
                return true;
            }

            // Popup item click
            if (open) {
                int popupHeight = Math.min(items.size(), MAX_VISIBLE_ITEMS) * ITEM_HEIGHT + 4;
                int popupY = y + height + 2;
                if (mx >= x && mx < x + width && my >= popupY && my < popupY + popupHeight) {
                    int clickedIdx = (int) ((my - (popupY + 2) + scrollOffset) / ITEM_HEIGHT);
                    if (clickedIdx >= 0 && clickedIdx < items.size()) {
                        this.selected = items.get(clickedIdx);
                        this.open = false;
                        if (onSelect != null) {
                            onSelect.accept(this.selected.value());
                        }
                    }
                    return true;
                } else {
                    this.open = false;
                }
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (open) {
            int maxScroll = Math.max(0, items.size() * ITEM_HEIGHT - MAX_VISIBLE_ITEMS * ITEM_HEIGHT);
            if (verticalAmount > 0) {
                scrollOffset = Math.max(0, scrollOffset - ITEM_HEIGHT);
            } else if (verticalAmount < 0) {
                scrollOffset = Math.min(maxScroll, scrollOffset + ITEM_HEIGHT);
            }
            return true;
        }
        return false;
    }
}
