package com.astrolddd.commongui.anim;

/**
 * 2nd-order damped harmonic oscillator spring physics model.
 * Produces organic, natural motion with physical stiffness and damping.
 *
 * Acceleration: a = stiffness * (target - position) - damping * velocity
 */
public final class Spring {
    private static final float MAX_SUBSTEP = 1.0f / 120.0f;

    // Presets for common UI interactions
    public static final float BOUNCY_STIFFNESS = 260.0f;
    public static final float BOUNCY_DAMPING = 18.0f;

    public static final float SMOOTH_STIFFNESS = 180.0f;
    public static final float SMOOTH_DAMPING = 22.0f;

    public static final float SNAPPY_STIFFNESS = 320.0f;
    public static final float SNAPPY_DAMPING = 28.0f;

    // Critically damped preset: swift, natural motion with strictly zero overshoot or jiggle
    public static final float CRISP_STIFFNESS = 320.0f;
    public static final float CRISP_DAMPING = 38.0f;

    private float value;
    private float velocity;
    private float target;
    private float stiffness;
    private float damping;

    public Spring(float initialValue) {
        this(initialValue, SMOOTH_STIFFNESS, SMOOTH_DAMPING);
    }

    public Spring(float initialValue, float stiffness, float damping) {
        this.value = initialValue;
        this.target = initialValue;
        this.velocity = 0.0f;
        this.stiffness = stiffness;
        this.damping = damping;
    }

    public void configure(float stiffness, float damping) {
        this.stiffness = stiffness;
        this.damping = damping;
    }

    public void setTarget(float target) {
        this.target = target;
    }

    public float getTarget() {
        return target;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }

    public float getVelocity() {
        return velocity;
    }

    public void setVelocity(float velocity) {
        this.velocity = velocity;
    }

    public void snapTo(float target) {
        this.target = target;
        this.value = target;
        this.velocity = 0.0f;
    }

    /**
     * Steps the simulation forward by dt (in seconds).
     * Uses sub-stepping for numerical stability under frame-rate variations.
     */
    public void step(float dt) {
        if (dt <= 0.0f) return;
        // Clamp large frame lags (e.g. window pause/resize) to prevent physics explosion
        float safeDt = Math.min(0.08f, dt);
        int steps = (int) Math.ceil(safeDt / MAX_SUBSTEP);
        float h = safeDt / steps;
        for (int i = 0; i < steps; i++) {
            float accel = (target - value) * stiffness - velocity * damping;
            velocity += accel * h;
            value += velocity * h;
        }
        if (isSettled(0.0005f)) {
            value = target;
            velocity = 0.0f;
        }
    }

    /**
     * Updates target and steps forward by dt.
     */
    public void step(float newTarget, float dt) {
        this.target = newTarget;
        step(dt);
    }

    public boolean isSettled(float epsilon) {
        return Math.abs(target - value) < epsilon && Math.abs(velocity) < epsilon;
    }
}
