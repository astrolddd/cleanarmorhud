package com.astrolddd.commongui.anim;

public final class Anim {
    private Anim() {}

    public static float lerp(float from, float to, float t) {
        return from + (to - from) * Easing.clamp01(t);
    }

    public static float approach(float current, float target, float durationMs, float deltaMs) {
        if (durationMs <= 0.0f) return target;
        float step = deltaMs / durationMs;
        if (current < target) {
            return Math.min(target, current + step);
        } else if (current > target) {
            return Math.max(target, current - step);
        }
        return target;
    }

    public static int lerpColor(int from, int to, float t) {
        float factor = Easing.clamp01(t);
        int a = Math.round(((from >>> 24) & 0xFF) + (((to >>> 24) & 0xFF) - ((from >>> 24) & 0xFF)) * factor);
        int r = Math.round(((from >>> 16) & 0xFF) + (((to >>> 16) & 0xFF) - ((from >>> 16) & 0xFF)) * factor);
        int g = Math.round(((from >>> 8) & 0xFF) + (((to >>> 8) & 0xFF) - ((from >>> 8) & 0xFF)) * factor);
        int b = Math.round((from & 0xFF) + ((to & 0xFF) - (from & 0xFF)) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
