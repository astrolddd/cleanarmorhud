package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.anim.Anim;
import com.astrolddd.commongui.draw.BlitBridge;
import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import com.astrolddd.commongui.update.UpdateChecker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Util;

import java.net.URI;
import java.util.function.Consumer;

public class DownloadIconButton extends Widget {
    private static final Identifier DOWNLOAD_ICON = Identifier.fromNamespaceAndPath("commongui", "textures/gui/download.png");

    private final UpdateChecker updateChecker;
    private final Consumer<DownloadIconButton> onPress;
    private final com.astrolddd.commongui.anim.Spring hoverSpring = new com.astrolddd.commongui.anim.Spring(0.0f, com.astrolddd.commongui.anim.Spring.SMOOTH_STIFFNESS, com.astrolddd.commongui.anim.Spring.SMOOTH_DAMPING);
    private long lastFrameNanos = 0;

    public DownloadIconButton(int x, int y, int size, UpdateChecker updateChecker, Consumer<DownloadIconButton> onPress) {
        super(x, y, size, size);
        this.updateChecker = updateChecker;
        this.onPress = onPress;
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible) return;
        boolean hasUpdate = updateChecker != null && updateChecker.isUpdateAvailable();
        if (!hasUpdate) return;

        updateHover(mouseX, mouseY);

        long now = System.nanoTime();
        float dt = lastFrameNanos == 0 ? 0.016f : (float) ((now - lastFrameNanos) / 1_000_000_000.0);
        lastFrameNanos = now;

        hoverSpring.step((hovered && enabled) ? 1.0f : 0.0f, dt);
        float hoverProgress = hoverSpring.getValue();

        int bgColor = Anim.lerpColor(0x3310B981, 0x5510B981, hoverProgress); // Emerald glow
        int iconColor = Anim.lerpColor(0xFF34D399, 0xFFFFFFFF, hoverProgress);
        int borderColor = Anim.lerpColor(0x6634D399, 0xCC34D399, hoverProgress);

        Draw.pill(g, x, y, width, height, bgColor);
        Draw.pillOutline(g, x, y, width, height, 1, borderColor);

        int iconSize = 12;
        int iconX = x + (width - iconSize) / 2;
        int iconY = y + (height - iconSize) / 2;
        BlitBridge.blit(g, DOWNLOAD_ICON, iconX, iconY, 0.0f, 0.0f, iconSize, iconSize, 48, 48, 48, 48, iconColor);

        if (hovered) {
            Font font = Minecraft.getInstance().font;
            String ver = updateChecker.latestVersion();
            g.setTooltipForNextFrame(font, UiTheme.text("New version available: v" + ver + " (Click to download)"), mouseX, mouseY);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!visible || !enabled) return false;
        boolean hasUpdate = updateChecker != null && updateChecker.isUpdateAvailable();
        if (!hasUpdate) return false;

        if (isLeftClick(event) && isMouseOver(event.x(), event.y())) {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.0F));
            if (onPress != null) {
                onPress.accept(this);
            } else {
                String dlUrl = updateChecker.getDownloadUrl();
                if (dlUrl != null && !dlUrl.isEmpty()) {
                    UpdateChecker.openUrl(dlUrl);
                }
            }
            return true;
        }
        return false;
    }
}
