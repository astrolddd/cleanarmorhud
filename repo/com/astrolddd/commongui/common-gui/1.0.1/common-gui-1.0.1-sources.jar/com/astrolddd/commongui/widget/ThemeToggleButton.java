package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.anim.Anim;
import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;

import java.util.function.Consumer;

public class ThemeToggleButton extends Widget {
    private static final Identifier MOON_ICON = Identifier.fromNamespaceAndPath("commongui", "textures/gui/moon.png");
    private static final Identifier SUN_ICON = Identifier.fromNamespaceAndPath("commongui", "textures/gui/sun.png");

    private final Consumer<ThemeToggleButton> onToggle;
    private final com.astrolddd.commongui.anim.Spring hoverSpring = new com.astrolddd.commongui.anim.Spring(0.0f, com.astrolddd.commongui.anim.Spring.SMOOTH_STIFFNESS, com.astrolddd.commongui.anim.Spring.SMOOTH_DAMPING);
    private long lastFrameNanos = 0;

    public ThemeToggleButton(int x, int y, int size, Consumer<ThemeToggleButton> onToggle) {
        super(x, y, size, size);
        this.onToggle = onToggle;
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible) return;
        updateHover(mouseX, mouseY);

        long now = System.nanoTime();
        float dt = lastFrameNanos == 0 ? 0.016f : (float) ((now - lastFrameNanos) / 1_000_000_000.0);
        lastFrameNanos = now;

        hoverSpring.step((hovered && enabled) ? 1.0f : 0.0f, dt);
        float hoverProgress = hoverSpring.getValue();

        int bgColor = Anim.lerpColor(UiTheme.BTN_IDLE, UiTheme.BTN_HOVER, hoverProgress);
        int iconColor = Anim.lerpColor(UiTheme.TEXT_SECONDARY, UiTheme.TEXT_PRIMARY, hoverProgress);

        // Circular rounded button background & border
        Draw.pill(g, x, y, width, height, bgColor);
        Draw.pillOutline(g, x, y, width, height, 1, UiTheme.BTN_BORDER);

        // In light mode show moon icon (to switch to dark), in dark mode show sun icon (to switch to light)
        boolean dark = UiTheme.isDark();
        Identifier icon = dark ? SUN_ICON : MOON_ICON;

        int iconSize = 12;
        int iconX = x + (width - iconSize) / 2;
        int iconY = y + (height - iconSize) / 2;
        com.astrolddd.commongui.draw.BlitBridge.blit(g, icon, iconX, iconY, 0.0f, 0.0f, iconSize, iconSize, 64, 64, 64, 64, iconColor);

        if (hovered) {
            Font font = Minecraft.getInstance().font;
            Component tip = Component.literal(dark ? "Switch to Warm Light Theme" : "Switch to Dark Theme");
            g.setTooltipForNextFrame(font, tip, mouseX, mouseY);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!visible || !enabled) return false;
        if (isLeftClick(event) && isMouseOver(event.x(), event.y())) {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.0F));
            if (onToggle != null) {
                onToggle.accept(this);
            }
            return true;
        }
        return false;
    }
}
