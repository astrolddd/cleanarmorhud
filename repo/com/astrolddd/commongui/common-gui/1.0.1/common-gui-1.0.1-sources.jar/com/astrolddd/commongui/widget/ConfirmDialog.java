package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class ConfirmDialog {
    private final String title;
    private final String message;
    private final Runnable onConfirm;
    private final Runnable onCancel;

    private final String confirmLabel;
    private final String cancelLabel;
    private final RoundedButton confirmBtn;
    private final RoundedButton cancelBtn;
    private boolean active = false;

    public ConfirmDialog(String title, String message, Runnable onConfirm, Runnable onCancel) {
        this(title, message, "Confirm", "Cancel", onConfirm, onCancel);
    }

    public ConfirmDialog(String title, String message, String confirmLabel, String cancelLabel, Runnable onConfirm, Runnable onCancel) {
        this.title = title;
        this.message = message;
        this.confirmLabel = confirmLabel;
        this.cancelLabel = cancelLabel;
        this.onConfirm = onConfirm;
        this.onCancel = onCancel;

        this.cancelBtn = new RoundedButton(0, 0, 80, 24, Component.literal(cancelLabel), b -> {
            this.active = false;
            if (onCancel != null) onCancel.run();
        });

        this.confirmBtn = new RoundedButton(0, 0, 80, 24, Component.literal(confirmLabel), b -> {
            this.active = false;
            if (onConfirm != null) onConfirm.run();
        });
    }

    public boolean isActive() {
        return active;
    }

    public void show() {
        this.active = true;
    }

    public void close() {
        this.active = false;
    }

    public void render(GuiGraphicsExtractor g, int screenWidth, int screenHeight, int mouseX, int mouseY, float delta) {
        if (!active) return;

        // Semi-transparent dim background
        g.fill(0, 0, screenWidth, screenHeight, 0x66000000);

        Font font = Minecraft.getInstance().font;
        Component cleanTitle = UiTheme.text(title);
        Component cleanMsg = UiTheme.text(message);
        int titleW = font.width(cleanTitle);
        int rawMsgW = font.width(cleanMsg);
        int dialogW = Math.max(340, Math.min(480, Math.max(titleW + 48, rawMsgW + 48)));
        var lines = font.split(cleanMsg, dialogW - 36);
        int lineCount = Math.max(1, lines.size());

        int textTotalH = lineCount * 12;
        int dialogH = Math.max(130, 20 + 14 + 10 + textTotalH + 20 + 24 + 16);
        int dialogX = (screenWidth - dialogW) / 2;
        int dialogY = (screenHeight - dialogH) / 2;

        Draw.softShadow(g, dialogX, dialogY, dialogW, dialogH, UiTheme.RADIUS_CARD, 4, 0x70);
        Draw.roundedRect(g, dialogX, dialogY, dialogW, dialogH, UiTheme.RADIUS_CARD, UiTheme.POPUP_BG);
        Draw.roundedOutline(g, dialogX, dialogY, dialogW, dialogH, UiTheme.RADIUS_CARD, 1, UiTheme.POPUP_BORDER);

        g.text(font, cleanTitle, dialogX + (dialogW - titleW) / 2, dialogY + 18, UiTheme.TEXT_PRIMARY, false);

        int textY = dialogY + 38;
        for (var line : lines) {
            int lineW = font.width(line);
            g.text(font, line, dialogX + (dialogW - lineW) / 2, textY, UiTheme.TEXT_SECONDARY, false);
            textY += 12;
        }

        // Buttons
        int cancelBtnW = Math.max(80, font.width(UiTheme.text(cancelLabel)) + 24);
        int confirmBtnW = Math.max(80, font.width(UiTheme.text(confirmLabel)) + 24);
        cancelBtn.width = cancelBtnW;
        confirmBtn.width = confirmBtnW;

        int totalBtnW = cancelBtnW + 16 + confirmBtnW;
        int startBtnX = dialogX + (dialogW - totalBtnW) / 2;
        int btnY = dialogY + dialogH - 38;

        cancelBtn.x = startBtnX;
        cancelBtn.y = btnY;
        confirmBtn.x = startBtnX + cancelBtnW + 16;
        confirmBtn.y = btnY;

        cancelBtn.extractWidgetRenderState(g, mouseX, mouseY, delta);
        confirmBtn.extractWidgetRenderState(g, mouseX, mouseY, delta);
    }

    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!active) return false;
        if (cancelBtn.mouseClicked(event, doubleClick)) return true;
        if (confirmBtn.mouseClicked(event, doubleClick)) return true;
        return true; // Consume clicks while dialog is open
    }
}
