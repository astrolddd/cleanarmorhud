package com.astrolddd.commongui.widget;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;

public abstract class Widget {
    public int x;
    public int y;
    public int width;
    public int height;
    public boolean enabled = true;
    public boolean visible = true;
    public boolean focused = false;
    protected boolean hovered = false;
    protected String tooltip = null;

    public Widget(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public int getX() { return x; }
    public int getY() { return y; }

    public boolean isMouseOver(double mouseX, double mouseY) {
        return enabled && visible && mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    public void updateHover(double mouseX, double mouseY) {
        this.hovered = isMouseOver(mouseX, mouseY);
    }

    public String getTooltip() {
        return tooltip;
    }

    public void setTooltip(String tooltip) {
        this.tooltip = tooltip;
    }

    public static boolean isLeftClick(MouseButtonEvent event) {
        return event != null && (event.button() == 0 || event.button() == 1);
    }

    public abstract void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta);

    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        return false;
    }

    public boolean mouseReleased(MouseButtonEvent event) {
        return false;
    }

    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return false;
    }

    public boolean keyPressed(KeyEvent event) {
        return false;
    }

    public boolean charTyped(CharacterEvent event) {
        return false;
    }
}
