package com.astrolddd.commongui.update;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.Version;
import net.fabricmc.loader.api.VersionParsingException;
import net.minecraft.SharedConstants;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

public final class UpdateChecker {
    private static final String API = "https://api.modrinth.com/v2";
    private static final Duration TIMEOUT = Duration.ofSeconds(10);
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(TIMEOUT)
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private static final Map<String, UpdateChecker> INSTANCES = new ConcurrentHashMap<>();
    private static final Set<String> TOASTED_MODS = ConcurrentHashMap.newKeySet();

    private final String modId;
    private final String projectSlug;
    private final String currentVersionString;
    private final boolean toastOnLaunch;

    private final AtomicBoolean isChecking = new AtomicBoolean(false);
    private volatile boolean checked = false;
    private volatile boolean updateAvailable = false;
    private volatile String latestVersion = "";
    private volatile String changelog = "";
    private volatile @Nullable String downloadUrl;
    private volatile String projectUrl;

    public UpdateChecker(String modId, String projectSlug, boolean toastOnLaunch) {
        this.modId = modId;
        this.projectSlug = projectSlug;
        this.toastOnLaunch = toastOnLaunch;
        this.projectUrl = "https://modrinth.com/mod/" + projectSlug;

        Optional<ModContainer> container = FabricLoader.getInstance().getModContainer(modId);
        this.currentVersionString = container.map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("1.0.0");
    }

    public static UpdateChecker register(String modId, String projectSlug, boolean toastOnLaunch) {
        UpdateChecker checker = new UpdateChecker(modId, projectSlug, toastOnLaunch);
        INSTANCES.put(modId, checker);
        checker.checkAsync(null);
        return checker;
    }

    public static @Nullable UpdateChecker get(String modId) {
        return INSTANCES.get(modId);
    }

    public String modId() {
        return modId;
    }

    public String projectSlug() {
        return projectSlug;
    }

    public String currentVersion() {
        return currentVersionString;
    }

    public String latestVersion() {
        return latestVersion.isEmpty() ? currentVersionString : latestVersion;
    }

    public boolean isChecked() {
        return checked;
    }

    public boolean isUpdateAvailable() {
        return updateAvailable;
    }

    public String getChangelog() {
        return changelog;
    }

    public @Nullable String getDownloadUrl() {
        return downloadUrl != null ? downloadUrl : projectUrl;
    }

    public String getProjectUrl() {
        return projectUrl;
    }

    public void checkAsync(@Nullable Consumer<UpdateChecker> onComplete) {
        if (!isChecking.compareAndSet(false, true)) {
            if (checked && onComplete != null) {
                onComplete.accept(this);
            }
            return;
        }

        Thread thread = new Thread(() -> {
            try {
                performCheck();
                if (updateAvailable && toastOnLaunch && TOASTED_MODS.add(modId)) {
                    UpdateToast.show("Update Available", "New version " + latestVersion + " available!");
                }
            } catch (Exception ignored) {
            } finally {
                checked = true;
                isChecking.set(false);
                if (onComplete != null) {
                    onComplete.accept(this);
                }
            }
        }, "UpdateChecker-" + modId);
        thread.setDaemon(true);
        thread.setPriority(Thread.MIN_PRIORITY);
        thread.start();
    }

    private void performCheck() throws IOException, InterruptedException {
        String url = API + "/project/" + projectSlug + "/version";
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .header("User-Agent", "CommonGUI/1.0.1 (UpdateChecker)")
                .header("Accept", "application/json")
                .timeout(TIMEOUT)
                .GET()
                .build();

        HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            return;
        }

        JsonElement root = JsonParser.parseString(response.body());
        if (!root.isJsonArray()) {
            return;
        }

        String gameVersion = SharedConstants.getCurrentVersion().name();
        Version installedVer = parseVersion(currentVersionString);

        JsonObject newestCandidate = null;
        Version newestVer = null;
        JsonObject newestOverallCandidate = null;
        Version newestOverallVer = null;

        for (JsonElement el : root.getAsJsonArray()) {
            if (!el.isJsonObject()) continue;
            JsonObject obj = el.getAsJsonObject();

            String verStr = getString(obj, "version_number", "");
            Version parsed = parseVersion(verStr);
            if (parsed != null) {
                if (newestOverallVer == null || parsed.compareTo(newestOverallVer) > 0) {
                    newestOverallCandidate = obj;
                    newestOverallVer = parsed;
                }
            }

            if (!isForThisGameVersion(obj, gameVersion)) continue;

            if (parsed != null) {
                if (newestVer == null || parsed.compareTo(newestVer) > 0) {
                    newestCandidate = obj;
                    newestVer = parsed;
                }
            }
        }

        JsonObject chosen = newestCandidate != null ? newestCandidate : newestOverallCandidate;
        if (chosen != null) {
            this.latestVersion = getString(chosen, "version_number", "");
            this.changelog = getString(chosen, "changelog", "");

            JsonArray files = chosen.has("files") && chosen.get("files").isJsonArray()
                    ? chosen.getAsJsonArray("files") : null;
            if (files != null && !files.isEmpty()) {
                JsonObject primaryFile = files.get(0).getAsJsonObject();
                for (JsonElement f : files) {
                    if (f.isJsonObject() && f.getAsJsonObject().has("primary") && f.getAsJsonObject().get("primary").getAsBoolean()) {
                        primaryFile = f.getAsJsonObject();
                        break;
                    }
                }
                if (primaryFile.has("url") && !primaryFile.get("url").isJsonNull()) {
                    this.downloadUrl = primaryFile.get("url").getAsString();
                }
            }
        }

        if (newestCandidate != null && newestVer != null && installedVer != null && newestVer.compareTo(installedVer) > 0) {
            this.updateAvailable = true;
        }
    }

    private static boolean isForThisGameVersion(JsonObject versionObj, String gameVersion) {
        List<String> gameVersions = getStrings(versionObj, "game_versions");
        List<String> loaders = getStrings(versionObj, "loaders");
        boolean loaderMatch = loaders.stream().anyMatch(l -> l.equalsIgnoreCase("fabric"));
        boolean versionMatch = gameVersions.contains(gameVersion);
        return loaderMatch && versionMatch;
    }

    private static List<String> getStrings(JsonObject obj, String key) {
        List<String> list = new ArrayList<>();
        if (obj.has(key) && obj.get(key).isJsonArray()) {
            for (JsonElement el : obj.getAsJsonArray(key)) {
                if (el.isJsonPrimitive()) {
                    list.add(el.getAsString());
                }
            }
        }
        return list;
    }

    private static String getString(JsonObject obj, String key, String fallback) {
        if (obj.has(key) && !obj.get(key).isJsonNull()) {
            return obj.get(key).getAsString();
        }
        return fallback;
    }

    private static @Nullable Version parseVersion(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String clean = raw.trim();
        if (clean.startsWith("v") || clean.startsWith("V")) {
            clean = clean.substring(1);
        }
        // If there's a build/minecraft suffix like "-mc26.2" or "+26.2", trim or parse
        try {
            return Version.parse(clean);
        } catch (VersionParsingException ignored) {
            // Try cleaning up dash suffix if standard semver
            int dash = clean.indexOf('-');
            if (dash > 0) {
                try {
                    return Version.parse(clean.substring(0, dash));
                } catch (VersionParsingException e) {
                    return null;
                }
            }
            return null;
        }
    }

    public static void openUrl(String url) {
        if (url == null || url.isBlank()) return;
        try {
            if (java.awt.Desktop.isDesktopSupported() && java.awt.Desktop.getDesktop().isSupported(java.awt.Desktop.Action.BROWSE)) {
                java.awt.Desktop.getDesktop().browse(URI.create(url));
                return;
            }
        } catch (Throwable ignored) {}
        try {
            String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            if (os.contains("win")) {
                Runtime.getRuntime().exec(new String[]{"cmd", "/c", "start", "", url});
            } else if (os.contains("mac")) {
                Runtime.getRuntime().exec(new String[]{"open", url});
            } else {
                Runtime.getRuntime().exec(new String[]{"xdg-open", url});
            }
        } catch (Throwable ignored) {}
    }
}
