package com.astrolddd.commongui.update;

import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.toasts.Toast;
import net.minecraft.client.gui.components.toasts.ToastManager;
import net.minecraft.network.chat.Component;

public class UpdateToast implements Toast {
    private static final Object TOKEN = new Object();
    private final Component title;
    private final Component message;
    private final long displayDurationMs;
    private long firstRenderTime = -1;
    private Visibility wantedVisibility = Visibility.SHOW;

    public UpdateToast(String titleText, String messageText) {
        this(titleText, messageText, 6000L);
    }

    public UpdateToast(String titleText, String messageText, long displayDurationMs) {
        this.title = UiTheme.text(titleText);
        this.message = UiTheme.text(messageText);
        this.displayDurationMs = displayDurationMs;
    }

    public static void show(String title, String message) {
        Minecraft mc = Minecraft.getInstance();
        if (mc != null && mc.gui != null && mc.gui.toastManager() != null) {
            mc.gui.toastManager().addToast(new UpdateToast(title, message));
        }
    }

    @Override
    public Visibility getWantedVisibility() {
        return wantedVisibility;
    }

    @Override
    public void update(ToastManager manager, long time) {
        if (firstRenderTime < 0) {
            firstRenderTime = time;
        }
        double multiplier = manager.getNotificationDisplayTimeMultiplier();
        if (time - firstRenderTime >= (long) (displayDurationMs * multiplier)) {
            wantedVisibility = Visibility.HIDE;
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, Font font, long time) {
        int w = width();
        int h = height();

        // Sleek translucent glass card
        Draw.roundedRect(graphics, 0, 0, w, h, 6, 0xEE111319);
        Draw.roundedOutline(graphics, 0, 0, w, h, 6, 1, 0x33FFFFFF);

        // Vibrant cyan accent bar
        Draw.pill(graphics, 6, 6, 3, h - 12, 0xFF38BDF8);

        // Download mini icon indicator
        int iconX = 14;
        int iconY = 10;
        Draw.rect(graphics, iconX + 2, iconY, 2, 5, 0xFF38BDF8);
        Draw.rect(graphics, iconX + 1, iconY + 3, 4, 1, 0xFF38BDF8);
        Draw.rect(graphics, iconX, iconY + 7, 6, 1, 0xFF38BDF8);

        // Text lines
        graphics.text(font, title, 26, 6, 0xFF38BDF8, false);
        graphics.text(font, message, 26, 18, 0xFFE2E8F0, false);
    }

    @Override
    public int width() {
        return 200;
    }

    @Override
    public int height() {
        return 32;
    }

    @Override
    public Object getToken() {
        return TOKEN;
    }
}
