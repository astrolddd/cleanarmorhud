package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.anim.Anim;
import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.function.Consumer;

public class ToggleSwitch extends Widget {
    private boolean state;
    private final Consumer<Boolean> onToggle;
    private float progress;
    private float hoverProgress = 0.0f;
    private long lastFrameNanos = 0;

    public ToggleSwitch(int x, int y, int width, int height, boolean initialState, Consumer<Boolean> onToggle) {
        super(x, y, width, height);
        this.state = initialState;
        this.onToggle = onToggle;
        this.progress = initialState ? 1.0f : 0.0f;
    }

    public boolean getState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public void snapState(boolean state) {
        this.state = state;
        this.progress = state ? 1.0f : 0.0f;
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible) return;
        updateHover(mouseX, mouseY);

        long now = System.nanoTime();
        float dt = lastFrameNanos == 0 ? 0.016f : (float) ((now - lastFrameNanos) / 1_000_000_000.0);
        lastFrameNanos = now;

        // Smooth critically-damped progression with strictly zero overshoot or jiggle
        float target = state ? 1.0f : 0.0f;
        float diff = target - progress;
        if (Math.abs(diff) < 0.001f) {
            progress = target;
        } else {
            float factor = 1.0f - (float) Math.exp(-22.0f * dt);
            progress += diff * factor;
        }

        float targetHover = (hovered && enabled) ? 1.0f : 0.0f;
        hoverProgress += (targetHover - hoverProgress) * (1.0f - (float) Math.exp(-18.0f * dt));

        int offColor = UiTheme.isDark() ? 0x33FFFFFF : 0xFFD8D2C4;
        if (hoverProgress > 0.01f) {
            offColor = Anim.lerpColor(offColor, UiTheme.isDark() ? 0x4DFFFFFF : 0xFFC8C2B4, hoverProgress);
        }
        int onColor = UiTheme.TOGGLE_ON;
        if (hoverProgress > 0.01f) {
            onColor = Anim.lerpColor(onColor, 0xFF4FD89A, hoverProgress);
        }
        int trackColor = Anim.lerpColor(offColor, onColor, progress);

        // Smooth pill track
        Draw.pill(g, x, y, width, height, trackColor);
        int trackBorder = Anim.lerpColor(0x20FFFFFF, 0x35000000, progress);
        Draw.pillOutline(g, x, y, width, height, 1, trackBorder);

        // Knob sizing & position
        int knobPadding = 2;
        int knobDiameter = height - (knobPadding * 2);
        int travelDistance = width - knobDiameter - (knobPadding * 2);
        int knobX = (int) Math.round(x + knobPadding + travelDistance * progress);
        int knobY = y + knobPadding;

        // Knob soft shadow
        Draw.softShadow(g, knobX, knobY, knobDiameter, knobDiameter, knobDiameter / 2, 2, 0x45);
        // Pure white circular knob
        Draw.pill(g, knobX, knobY, knobDiameter, knobDiameter, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!enabled || !visible) return false;
        if (isLeftClick(event) && isMouseOver(event.x(), event.y())) {
            this.state = !this.state;
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.0F));
            if (onToggle != null) {
                onToggle.accept(this.state);
            }
            return true;
        }
        return false;
    }
}
