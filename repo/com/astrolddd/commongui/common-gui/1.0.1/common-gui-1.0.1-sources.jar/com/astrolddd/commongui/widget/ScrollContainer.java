package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.anim.Anim;
import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;

public class ScrollContainer extends Widget {
    private float scrollY = 0.0f;
    private float targetScrollY = 0.0f;
    private int contentHeight = 0;
    private float scrollbarAlpha = 0.0f;

    private boolean draggingScrollbar = false;
    private float dragGrabOffset = 0.0f;

    private long lastFrameNanos = 0;

    public ScrollContainer(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public void setContentHeight(int contentHeight) {
        this.contentHeight = contentHeight;
        clampTargetScroll();
    }

    public float getScrollY() {
        return scrollY;
    }

    public void setScrollY(float scroll) {
        this.scrollY = scroll;
        this.targetScrollY = scroll;
        this.lastFrameNanos = 0;
        clampTargetScroll();
    }

    public int getMaxScroll() {
        return Math.max(0, contentHeight - height);
    }

    private void clampTargetScroll() {
        int maxScroll = getMaxScroll();
        targetScrollY = Math.max(0.0f, Math.min(maxScroll, targetScrollY));
        if (contentHeight <= height) {
            scrollY = 0.0f;
            targetScrollY = 0.0f;
        } else {
            scrollY = Math.max(0.0f, Math.min(maxScroll, scrollY));
        }
    }

    public void beginRender(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);

        long now = System.nanoTime();
        if (lastFrameNanos == 0) {
            lastFrameNanos = now;
        }
        float dt = (float) ((now - lastFrameNanos) / 1_000_000_000.0);
        lastFrameNanos = now;
        dt = Math.min(0.05f, Math.max(0.001f, dt));

        int maxScroll = getMaxScroll();
        if (maxScroll <= 0) {
            scrollY = 0.0f;
            targetScrollY = 0.0f;
        } else {
            // Silky smooth ease-out spring gliding (14.0 decay factor = ~160ms settling time)
            float diff = targetScrollY - scrollY;
            if (Math.abs(diff) < 0.05f) {
                scrollY = targetScrollY;
            } else {
                float decayFactor = 1.0f - (float) Math.exp(-14.0 * dt);
                scrollY += diff * decayFactor;
            }
            scrollY = Math.max(0.0f, Math.min(maxScroll, scrollY));
        }

        // Scrollbar fade logic
        boolean isScrolling = Math.abs(scrollY - targetScrollY) > 0.5f;
        float targetAlpha = (hovered || isScrolling || draggingScrollbar) ? 1.0f : 0.0f;
        scrollbarAlpha = Anim.approach(scrollbarAlpha, targetAlpha, 180.0f, delta * 50.0f);

        // Scissor clipping
        g.enableScissor(x, y, x + width, y + height);
    }

    public void endRender(GuiGraphicsExtractor g) {
        g.disableScissor();

        // Draw refined rounded scrollbar pill if content exceeds height and alpha > 0
        int maxScroll = getMaxScroll();
        if (maxScroll > 0 && scrollbarAlpha > 0.02f) {
            int scrollbarW = getScrollbarWidth();
            int scrollbarX = getScrollbarX();
            int barHeight = getScrollbarHeight();
            int barY = getScrollbarY();

            // Background track (subtle translucent pill)
            int trackAlpha = Math.round(0x20 * scrollbarAlpha);
            if (trackAlpha > 0) {
                int trackColor = (trackAlpha << 24) | 0x00808080;
                Draw.pill(g, scrollbarX, y + 2, scrollbarW, height - 4, trackColor);
            }

            // Scrollbar thumb pill
            int thumbAlpha = Math.round((draggingScrollbar ? 0xB0 : 0x70) * scrollbarAlpha);
            int thumbRgb = UiTheme.isDark() ? 0x00A0A0AA : 0x00555555;
            int barColor = (thumbAlpha << 24) | thumbRgb;

            Draw.pill(g, scrollbarX, barY, scrollbarW, barHeight, barColor);
        }
    }

    private int getScrollbarWidth() {
        return 4;
    }

    private int getScrollbarX() {
        return x + width - getScrollbarWidth() - 3;
    }

    private int getScrollbarHeight() {
        if (contentHeight <= 0) return height;
        float ratio = (float) height / (float) contentHeight;
        return Math.max(20, Math.min(height - 4, (int) (height * ratio)));
    }

    private int getScrollbarY() {
        int maxScroll = getMaxScroll();
        if (maxScroll <= 0) return y + 2;
        int barH = getScrollbarHeight();
        int trackH = height - 4 - barH;
        float progress = Math.max(0.0f, Math.min(1.0f, scrollY / (float) maxScroll));
        return y + 2 + Math.round(trackH * progress);
    }

    public boolean isOverScrollbar(double mouseX, double mouseY) {
        int maxScroll = getMaxScroll();
        if (maxScroll <= 0) return false;
        int sbX = getScrollbarX() - 4; // 4px padding for easy clicking
        int sbW = getScrollbarWidth() + 8;
        return mouseX >= sbX && mouseX <= sbX + sbW && mouseY >= y && mouseY <= y + height;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!enabled || !visible) return false;
        int maxScroll = getMaxScroll();
        if (maxScroll <= 0) return false;

        if (isLeftClick(event) && isOverScrollbar(event.x(), event.y())) {
            draggingScrollbar = true;
            int barY = getScrollbarY();
            int barH = getScrollbarHeight();
            if (event.y() >= barY && event.y() <= barY + barH) {
                dragGrabOffset = (float) (event.y() - barY);
            } else {
                dragGrabOffset = barH / 2.0f;
                int trackH = height - 4 - barH;
                if (trackH > 0) {
                    float progress = Math.max(0.0f, Math.min(1.0f, (float) (event.y() - y - 2 - dragGrabOffset) / (float) trackH));
                    targetScrollY = scrollY = progress * maxScroll;
                }
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (draggingScrollbar) {
            int maxScroll = getMaxScroll();
            int barH = getScrollbarHeight();
            int trackH = height - 4 - barH;
            if (trackH > 0) {
                float thumbY = (float) (event.y() - y - 2 - dragGrabOffset);
                float progress = Math.max(0.0f, Math.min(1.0f, thumbY / (float) trackH));
                targetScrollY = scrollY = progress * maxScroll;
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (isLeftClick(event) && draggingScrollbar) {
            draggingScrollbar = false;
            return true;
        }
        return false;
    }

    public boolean isMouseOverScrollArea(double mouseX, double mouseY) {
        return enabled && visible && mouseX >= x - 20 && mouseX < x + width + 20 && mouseY >= y - 30 && mouseY < y + height + 30;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (isMouseOverScrollArea(mouseX, mouseY)) {
            // Calibrated 28.0px wheel step for silky smooth ease-out navigation without overshoot or sudden snaps
            float step = 28.0f;
            targetScrollY -= (float) (verticalAmount * step);
            clampTargetScroll();
            return true;
        }
        return false;
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);
    }
}
