package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;

import java.util.Locale;
import java.util.function.Consumer;

public class ColorPickerWidget extends Widget {
    private int currentColor;
    private final boolean supportAlpha;
    private final Consumer<Integer> onColorChange;

    private float hue = 0.0f;
    private float sat = 1.0f;
    private float bri = 1.0f;
    private float alpha = 1.0f;

    private boolean draggingSb = false;
    private boolean draggingHue = false;
    private boolean draggingAlpha = false;

    // Dimensions
    private static final int SB_SIZE = 70;
    private static final int BAR_WIDTH = 12;

    public ColorPickerWidget(int x, int y, int initialColor, boolean supportAlpha, Consumer<Integer> onColorChange) {
        super(x, y, 170, 78);
        this.supportAlpha = supportAlpha;
        this.onColorChange = onColorChange;
        setColor(initialColor);
    }

    public int getColor() {
        return currentColor;
    }

    public void setColor(int argb) {
        this.currentColor = argb;
        this.alpha = supportAlpha ? ((argb >>> 24) & 0xFF) / 255.0f : 1.0f;
        float[] hsb = Draw.rgbToHsb(argb & 0x00FFFFFF);
        this.hue = hsb[0];
        this.sat = hsb[1];
        this.bri = hsb[2];
    }

    private void updateColorFromHsb() {
        int rgb = Draw.hsbToRgb(hue, sat, bri);
        int a = supportAlpha ? Math.round(alpha * 255.0f) : 255;
        this.currentColor = (a << 24) | (rgb & 0x00FFFFFF);
        if (onColorChange != null) {
            onColorChange.accept(this.currentColor);
        }
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible) return;
        updateHover(mouseX, mouseY);

        int sbX = x;
        int sbY = y;

        // Saturation / Brightness square
        Draw.drawSaturationBrightnessSquare(g, sbX, sbY, SB_SIZE, SB_SIZE, hue);
        Draw.roundedOutline(g, sbX, sbY, SB_SIZE, SB_SIZE, 0, 1, UiTheme.CARD_BORDER);

        // SB cursor
        int curX = sbX + Math.round(sat * (SB_SIZE - 1));
        int curY = sbY + Math.round((1.0f - bri) * (SB_SIZE - 1));
        Draw.circle(g, curX, curY, 3, 0xFFFFFFFF);
        Draw.circle(g, curX, curY, 2, 0xFF000000);

        // Hue bar
        int hueX = sbX + SB_SIZE + 8;
        int hueY = y;
        Draw.drawHueBar(g, hueX, hueY, BAR_WIDTH, SB_SIZE);
        Draw.roundedOutline(g, hueX, hueY, BAR_WIDTH, SB_SIZE, 0, 1, UiTheme.CARD_BORDER);

        // Hue indicator
        int hueIndicatorY = hueY + Math.round(hue * (SB_SIZE - 1));
        g.fill(hueX - 1, hueIndicatorY - 1, hueX + BAR_WIDTH + 1, hueIndicatorY + 2, 0xFFFFFFFF);
        g.fill(hueX, hueIndicatorY, hueX + BAR_WIDTH, hueIndicatorY + 1, 0xFF000000);

        // Alpha bar or preview
        int swatchX = hueX + BAR_WIDTH + 8;
        int swatchY = y;
        int swatchSize = 28;

        // Swatch checkerboard + color preview
        Draw.checkerboard(g, swatchX, swatchY, swatchSize, swatchSize, 4);
        Draw.roundedRect(g, swatchX, swatchY, swatchSize, swatchSize, 4, currentColor);
        Draw.roundedOutline(g, swatchX, swatchY, swatchSize, swatchSize, 4, 1, UiTheme.CARD_BORDER);

        // Hex string
        Font font = Minecraft.getInstance().font;
        String hex = String.format(Locale.ROOT, "#%06X", currentColor & 0x00FFFFFF);
        g.text(font, UiTheme.text(hex), swatchX, swatchY + swatchSize + 6, UiTheme.TEXT_PRIMARY, false);

        if (supportAlpha) {
            String alphaStr = Math.round(alpha * 100) + "%";
            g.text(font, UiTheme.text(alphaStr), swatchX, swatchY + swatchSize + 18, UiTheme.TEXT_SECONDARY, false);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (!enabled || !visible) return false;
        if (isLeftClick(event)) {
            double mx = event.x();
            double my = event.y();

            // Click in SB square
            if (mx >= x && mx < x + SB_SIZE && my >= y && my < y + SB_SIZE) {
                draggingSb = true;
                updateSbFromMouse(mx, my);
                return true;
            }

            // Click in Hue bar
            int hueX = x + SB_SIZE + 8;
            if (mx >= hueX && mx < hueX + BAR_WIDTH && my >= y && my < y + SB_SIZE) {
                draggingHue = true;
                updateHueFromMouse(my);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (draggingSb) {
            updateSbFromMouse(event.x(), event.y());
            return true;
        }
        if (draggingHue) {
            updateHueFromMouse(event.y());
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (isLeftClick(event)) {
            draggingSb = false;
            draggingHue = false;
            draggingAlpha = false;
        }
        return false;
    }

    private void updateSbFromMouse(double mx, double my) {
        this.sat = (float) Math.max(0.0, Math.min(1.0, (mx - x) / (SB_SIZE - 1)));
        this.bri = (float) Math.max(0.0, Math.min(1.0, 1.0 - (my - y) / (SB_SIZE - 1)));
        updateColorFromHsb();
    }

    private void updateHueFromMouse(double my) {
        this.hue = (float) Math.max(0.0, Math.min(1.0, (my - y) / (SB_SIZE - 1)));
        updateColorFromHsb();
    }
}
