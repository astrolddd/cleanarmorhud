package com.astrolddd.commongui.widget;

import com.astrolddd.commongui.draw.Draw;
import com.astrolddd.commongui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class SectionCard extends Widget {
    private final String title;
    private final String subtitle;

    public SectionCard(int x, int y, int width, int height, String title, String subtitle) {
        super(x, y, width, height);
        this.title = title;
        this.subtitle = subtitle;
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (!visible) return;

        // Card background & 1px border
        Draw.roundedRect(g, x, y, width, height, UiTheme.RADIUS_CARD, UiTheme.CARD_BG);
        Draw.roundedOutline(g, x, y, width, height, UiTheme.RADIUS_CARD, 1, UiTheme.CARD_BORDER);

        Font font = Minecraft.getInstance().font;
        int headerY = y + 12;

        if (title != null && !title.isBlank()) {
            g.text(font, UiTheme.text(title), x + 14, headerY, UiTheme.TEXT_PRIMARY, false);
            headerY += 12;
        }

        if (subtitle != null && !subtitle.isBlank()) {
            g.text(font, UiTheme.text(subtitle), x + 14, headerY, UiTheme.TEXT_SECONDARY, false);
        }
    }
}
